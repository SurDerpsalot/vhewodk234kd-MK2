import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
//import java.nio.LongBuffer;
/**
 * class for our heap structure
 * @author bfin96, maden
 * @version 1.3
 *
 */
public class MainMemory {
    /**
     * number of completely sorted values
     */
    private int darkzone;
    /**
     * number of unsorted positions
     */
    private int lightzone;
    /**
     * number of records in the heap
     */
    private int records;
    /**
     * number of bytes used in the heap (records * 8)
     */
    private int size;
    /**
     * heap storage
     */
    private byte[] list;
    /**
     * retrieves the byte array for editing
     * @return the byte array for editing
     */
    public byte[] getList() {
        return list;
    }
    /**
     * byte buffer wrapped to the list
     */
    private ByteBuffer buff;
    /**
     * retrieves the list buffer for editing
     * @return the list buffer for editing
     */
    public ByteBuffer getListBuff() {
        return buff;
    }
    /**
     * the input buffer to be used with the heap
     */
    private DataBuffer inputBuffer;
    /**
     * retrieves the inputBuffer
     * @return the inputBuffer
     */
    public DataBuffer getIn() {
        return inputBuffer;
    }
    /**
     * sets the inputBuffer
     * @param in is the new DataBuffer to replace inputBuffer
     */
    public void setIn(DataBuffer in) {
        inputBuffer = in;
    }
    /**
     * the output buffer to be used with the heap
     */
    private DataBuffer outputBuffer;
    /**
     * retrieves the outputBuffer
     * @return the outputBuffer
     */
    public DataBuffer getOut() {
        return outputBuffer;
    }
    /**
     * Sets the values of the outputbuffer
     * @param dB is the new DataBuffer being brought in
     */
    public void setOut(DataBuffer dB) {
        outputBuffer = dB;
    }
    /**
     * list of reading positions in the heap
     */
    //private ArrayList<Integer> positions;
    /**
     * sets the darkzone
     * @param dark the integer being set
     */
    public void setDark(int dark) {
        darkzone = dark;
    }
    /**
     * retrieves the darkzone
     * @return the darkzone
     */
    public int getDark() {
        return darkzone;
    }
    /**
     * sets the lightzone
     * @param light the integer being set
     */
    public void setLight(int light) {
        lightzone = light;
    }
    /**
     * retrieves the lightzone
     * @return the lightzone
     */
    public int getLight() {
        return lightzone;
    }
    /**
     * sets the records
     * @param rec the integer being set
     */
    public void setRec(int rec) {
        records = rec;
    }
    /**
     * retrieves the records
     * @return the records
     */
    public int getRec() {
        return records;
    }
    /**
     * sets the size
     * @param s the integer to be set
     */
    public void setSize(int s) {
        size = s;
    }
    /**
     * retrieves the size
     * @return the size
     */
    public int getSizeMainMem() {
        return size;
    }
    
    /**
     * constructor
     */
    public MainMemory()
    {
        list = new byte[32768];
        size = 0;
        records = 0;
        darkzone = 0;
        lightzone = 32767;
        buff = ByteBuffer.wrap(list);
    }
    /**
     * constructor 2
     * @param pos is the array of positions
     */
    public MainMemory(ArrayList<Integer> pos) {
        list = new byte[32768];
        size = 0;
        records = 0;
        darkzone = 0;
        lightzone = 32767;
        buff = ByteBuffer.wrap(list);
       // positions = pos;
        initialRunBlockLens = pos;
    }
    /**
     * insert an array of bytes into the heap
     * @param items the array of bytes
     * @return the success or failure of the insert operation
     */
    public boolean insert(byte[] items) {
        if (items == null) {
            return false;
        }
        if (items.length % 4096 != 0) {
            return false; //not a block
        }
        if (size + items.length > 4096 * 8) {
            return false; //out of bounds
        }
        ByteBuffer it = ByteBuffer.wrap(items);
        if (size == 0) { //first item
            buff.putLong(it.getLong());
            records = records + 1;
            size = size + 8;
        }
        while (it.hasRemaining())
        {
            buff.putLong(it.getLong());
            minHeapify(size);
            records = records + 1;
            size = size + 8;
            
        }
        return true;
    }
    /**
     * resets the size of the heap, as well as the sorted region.
     * It heapifies.
     */
    public void reset() {
        buff.clear();
        size = 0;
        records = 0;
        darkzone = 0;
        lightzone = 32767;
    }
    /**
     * build a minHeap
     */
    public void buildHeap() {
        int s = records;
        while (s > 0)
        {
            swap(s - 1, 0);
            s = s - 1;
            minHeapify(byteAddrFromRecNum(s));
        }
    }
   /** @param record is the 16-byte number with a value-key pair
    * @return float key is the LSB 4-bytes from the long
    */
    public static float getKey(long record) {
        byte[] test = new byte[8];
        ByteBuffer buff = ByteBuffer.wrap(test);
        buff.putLong(record);
        return buff.getFloat(4);
    }
   /**
    * @param record is the 16-byte number with a value-key pair
    * @return unsigned int value is the MSB 4-bytes from the long
    */
    public static long getValue(long record) {
        return (long)(record >>> 32); //logical shift right
    }
    /**
     * overloads the compareTo function to include long number comparisons
     * @param a first long number for comparison
     * @param b second long number for comparison
     * @return 0 if they are the same. A positive number if
     * a follows b, and a negative number if b precedes a.
     */
    public static int compareTo(long a, long b) {
        float aF = getKey(a);
        float bF = getKey(b);
        long aI = getValue(a);
        long bI = getValue(b);
        return (Float.compare(aF, bF) != 0 ) ? 
                Float.compare(aF, bF) : Long.compare(aI, bI);
        
    }
    /**
     * get the record number
     * @param bNum byte address of the start for your long
     * @return return the corresponding record number
     */
    public static int recNumFromByteAddr(int bNum) {
        return bNum / 8;
    }
    /**
     * get the record number
     * @param rNum record number of your long
     * @return return the corresponding byte address 
     * for the start of your number
     */
    public static int byteAddrFromRecNum(int rNum) {
        return rNum * 8;
    }
    /**
     * build a level for a minHeap
     * @param i the current byte address for the start of the long value 
     * in the heap. 
     * It is the start of the next Long address
     */
    private void minHeapify(int i) {
        int p = parent(i);
        if (p >= 0 && compareTo(buff.getLong(p), buff.getLong(i)) > 0 )
        {
            swap(i, p);
            minHeapify(p);
        }
    }
    
    /**
     * check if the heap is empty
     * @return positive if empty
     */
    public boolean isEmpty() {
        return (end() < 0) || buff.asLongBuffer().hasRemaining();
    }
    /**
     * get the number of bytes 
     * @return get the number of records
     */
    public int getSize() {
        return size;
    }
    /**
     * get the number of blocks in this heap
     * @return the size of the heap in blocks
     */
    public int getSizeBlocks() {
        return size / 4096;
    }
    /**
     * get the right child of pos i
     * @param i current position
     * @return the right child int
     */
    private int right(int i) {
        return (2 * i + 2) * 8;
    }
    /**
     * end of the region used to heapify. the value after the 
     * end() will be the maximum value in the darkzone
     * @return size - 1
     */
    private int end() {
        return size - 8;
    }
    /**
     * return the parent to a position in the heap
     * @param i the current position's byte address
     * @return the parent's byte address. If out of bounds, this will return -1
     */
    protected int parent(int i) {
        int j = recNumFromByteAddr(i);
        if (j < 1 || j > records || i % 8 != 0) {
            return -1;
        }
        return (j % 2 == 0) ? byteAddrFromRecNum((j - 1) / 2)
                : byteAddrFromRecNum(j / 2);
    }
    /**
     * get the position of the left child
     * @param i current position
     * @return the left child int
     */
    private int left(int i) {
        return (2 * i + 1) * 8;
    }
    /**
     * swap the current position with its parent
     * @param i current byte address
     * @param parent the parent of i
     * @return if swap was successful
     */
    protected Boolean swap(int i, int parent) {
        if (parent < i && parent >= 0 && i <= size) {
            long temp = buff.getLong(parent);
            buff.putLong(parent, buff.getLong(i));
            buff.putLong(i, temp);
            return true;
        }
        return false;
    }
    /**
     * when the caller of this class updates the positions
     * @param pos the new data for positionsList
     
    protected void updatePositions(ArrayList<Integer> pos) {
        positions = pos;
    }
    */
    /**
     * get the next block of data from the heap-sorted memory
     * @return the output buffer with the block of minimum values
     */
    protected DataBuffer popMinBlock() {
        outputBuffer.getBBuff().clear();
        for (int i = 0; i < 512; i++) {
            outputBuffer.getBBuff().putLong(popMinRecord());
        }
        return outputBuffer;
    }
    /**
     * returns the smallest value in the heap, and updates its structure
     * @return the smallest value in the heap
     */
    private long popMinRecord() {
        swap(end(), 0);
        size = end(); 
        records--;
        shrinkHeap(0);
        return buff.getLong(size);
    }
    /**
     * shrink the heap by one level
     * @param i the current byte address for the start of the long value 
     * in the heap. 
     * It is the start of the next Long address
     */
    private void shrinkHeap(int i) {
        if (i > size) { return; }
        if (left(i) > size) { return; }
        long left = buff.getLong(left(i));
        long right = buff.getLong(right(i));
        long curr = buff.getLong(0);
        int smallestpos = i;
        if (compareTo(curr, left) > 0 ) {
            smallestpos = left(i);
            curr = left;
        }
        if (compareTo(curr, right) > 0 ) {
            smallestpos = right(i);
            curr = right;
        }
        if (smallestpos != i) {
            swap(smallestpos, i);
            shrinkHeap(smallestpos);
            
        }
    }
    
    ////////////////////////////////////////////
    ///////////////////////////////////////////
    //////////////////////////////////////////
    /**
     *[b], the run lengths in blocks
     */
    private ArrayList<Integer> initialRunBlockLens;
    /**
     * [b2] the number of blocks that were read
     */
    private ArrayList<Integer> initialRunBlockLensRead; 
    /**
     * the next set of run lengths
     */
    private ArrayList<Integer> nextRunLens;
    /**
     * main memory's pointers to specific locations
     */
    private ArrayList<Integer> memoryBlockPositions;
    /**
     * if the run from the input file that is sent to this main memory block
     * is done being read
     */
    private ArrayList<Boolean> positionIsDone;
    /**
     * the smallest values in the main memory
     */
    private ArrayList<Record> smallestMergeValues;
    
    /**
     * resets the arrayLists associated with the positions
     * in the main memory space
     * @param length the number of blocks in memory to be used by this run. 
     * This value is expected to be <= 8
     */
    protected void resetPositions(int length) {
        
        memoryBlockPositions.clear();
        positionIsDone.clear();
        if (length > 8) { return; }
        int i; 
        for (i = 0; i < length; i++) {
            memoryBlockPositions.add(0);
            positionIsDone.add(false);
        }
        memoryBlockPositions.add(i - length);
    }
    /**
     * checks if a given run was completely read into the mainMemory buffer
     * @param runNumber the run number from the input file in question
     * @return true if all its blocks have been read
     */
    protected boolean isRunDoneReading(int runNumber) {
        return positionIsDone.get(runNumber);
    }
    /**
     * checks if all the runs from the input were completely read in
     * during the merge sort
     * @return true if all the blocks for the given run were read
     */
    protected boolean mergeReadAllDone() {
        for (int i = 0; i < memoryBlockPositions.size(); i++) {
            if (!positionIsDone.get(i)) { return false; }
        }
        return true;
    }
    /**
     * increments the block number that was read from a given input run, and 
     * updates positionIsDone to return true once the last block was read
     * into the main memory
     * @param runNumber the initial run's number
     */
    protected void incrementAndCheckBlockPosition(int runNumber) {
        initialRunBlockLensRead.set(runNumber % 8, 
                initialRunBlockLensRead.get(runNumber) + 1);
        positionIsDone.set(runNumber, (initialRunBlockLensRead.get(runNumber)
                >= initialRunBlockLens.get(runNumber)));
    }
    /**
     * holds information about the smallest values in each position of the 
     * main memory's merges runs
     * @author maden
     *
     */
    class Record {
        /**
         * The block in main memory this record is in
         */
        private int block;
        /**
         * The record's byte address (start at the block position)
         */
        private int position;
        /**
         * The long value of the record
         */
        private long value;
        /**
         * Constructor
         * @param b is the block it is contained in
         * @param p the record's byte address
         * @param v the long value of the record
         */
        public Record(int b, int p, long v) {
            block = b;
            position = p;
            value = v;
        }
    }
    
    /**
     * initializes the smallest values in each of the blocks in main memory
     * These are the sorted values at the first record in each block.
     */
    protected void initSmallestMergeVals() {
        smallestMergeValues.clear();
        smallestMergeValues.add( new Record(0, 0, buff.getLong(0)));
        for (int block = 1; block < positionIsDone.size(); block++) {
            int pos = 0;
            long nextValue = buff.getLong(block * 4096);
            while (pos < smallestMergeValues.size() && 
                    compareTo(nextValue, 
                    smallestMergeValues.get(pos).value) > 0) {
                pos++;
            }
            smallestMergeValues.add(pos, new Record(block, 0, nextValue));
        }
    }
    /**
     * pops the smallest value in the main memory during mergesort
     * and updates its indicators
     * @return -1 if it is not the end of the block. otherwise it
     * returns the block number in main memory that either needs refilled
     * or to be marked as empty
     */
    protected int popMinOutput() {
        Record smallest = smallestMergeValues.remove(0);
        outputBuffer.getBBuff().putLong(smallest.value);
        int nextPos = smallest.position + 8;
        if (nextPos >= 4096) { //the block for this run has been exhausted
            //need to add the next block!
            return smallest.block;
        }
        else { //ifthe next smallest value is just in the next record in memory
            long nextValue = buff.getLong(smallest.block * 4096 + nextPos);
            int listPos = 0; //position in the list
            while (listPos < smallestMergeValues.size() && 
                    compareTo(nextValue, 
                            smallestMergeValues.get(listPos).value) > 0) {
                listPos++;
            }
            smallestMergeValues.add(listPos, 
                new Record(smallest.block, nextPos, nextValue));
            return -1;
        }
    }
    /**
     * 
     * @param runNumber which run in the input file to grab the 
     * @param in the input file to grab a block from if possible
     * @return true if we successfully grabbed a new block
     */
    protected boolean grabNextBlock(int runNumber, RandomAccessFile in) {
        if (isRunDoneReading(runNumber)) {
            return false;
        }
        int nextBlock = initialRunBlockLensRead.get(runNumber);
        try {
            in.seek(nextBlock * 4096);
            in.readFully(inputBuffer.getBuff());
            buff.put(inputBuffer.getBuff(), runNumber % 8, 4096);
            incrementAndCheckBlockPosition(runNumber);         
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
        
        return true;
    }
    /**
     * merge and sort
     * @param in the input RAF
     * @param out the output RAF
     */
    public void mergesort(RandomAccessFile in, RandomAccessFile out) {
        int offset = 0;
        try {
            //runNumber is the expected run that is being processed
            for (int runNumber = 0; runNumber < nextRunLens.size();
                    runNumber++) {
                int memBlockNumber = 0; //the block number in mainMem
                while (memBlockNumber < nextRunLens.get(runNumber)) {
                    //inputRunPosition is the 
                    int blocksToUse = (Math.min(8, 
                            nextRunLens.get(runNumber)));
                    resetPositions(blocksToUse);
                    for (int inputRunPosition = 0; inputRunPosition 
                            < blocksToUse; inputRunPosition++) {
                        in.seek(offset);
                        in.readFully(inputBuffer.getBuff(), offset, 4096);
                        offset = offset + 4096 * 
                                initialRunBlockLens.get(runNumber);
                        incrementAndCheckBlockPosition(runNumber +
                                inputRunPosition); 
                    }
                    
                    memBlockNumber++;
                }
                //once the mainMemory has its first sets of data initialized, 
                //commence the merge sorting preparations
                //1. compare the smallest values in each run file
                initSmallestMergeVals();
                int blocksMerged = 0; //number of blocks that were run 
                //through mergesort to completion
                
                while (blocksMerged < nextRunLens.get(runNumber)) {
                    //loop until output buffer is full
                    for (int recNum = 0; recNum < 512; recNum++) {
                        int whichBlockNeedsRefreshed = popMinOutput();
                        if (whichBlockNeedsRefreshed != -1) {
                            grabNextBlock(whichBlockNeedsRefreshed, in);
                            blocksMerged++;
                        }
                    }
                    out.write(outputBuffer.getBuff());
                    outputBuffer.getBBuff().clear();
                }
            }
        } 
        catch (IOException e) {
            // ToDo Auto-generated catch block
            e.printStackTrace();
        }
    }

}
