import java.nio.ByteBuffer;

/**
 * @author maden
 * @version 1
 */
public class MainMemoryTest extends student.TestCase {

    /**
     * Test method for {@link MainMemory#MainMemory()}.
     */
    public void testmainMemory() {
        MainMemory test = new MainMemory();
        assertEquals(test.getSize(), 0);
        assertEquals(test.getList().length, 32768);
        assertEquals(test.getDark(), 0);
        assertEquals(test.getListBuff().capacity(), 32768);
        assertTrue(test.isEmpty());
    }

    /**
     * Test method for {@link MainMemory#compareTo(long, long)}.
     */
    public void testCompareTo() {
        assertTrue(MainMemory.compareTo((long)12, 0x0) > 0);
        assertTrue(MainMemory.compareTo(0x0, (long)12) < 0);
        assertTrue(MainMemory.compareTo(0xFFFFF, 0x0) > 0);
        assertTrue(MainMemory.compareTo(0x0, 0xFFFFF) < 0);
        assertEquals(MainMemory.compareTo(3, 3), 0);
        assertEquals(MainMemory.compareTo(0xFFFFF, 0xFFFFF), 0);
    }

    /**
     * Test method for {@link MainMemory#isEmpty()}.
     */
    public void testSwap() {
        MainMemory test = new MainMemory();
        test.getList()[0] = (byte)0; //20, 10   index 0
        test.getList()[1] = (byte)0; //40, 30
        test.getList()[2] = (byte)0; //20
        test.getList()[3] = (byte)40; //40
        test.getList()[4] = (byte)0; //20, 10 
        test.getList()[5] = (byte)0; //40, 30
        test.getList()[6] = (byte)0; //20
        test.getList()[7] = (byte)40; //40
        test.getList()[8] = (byte)0; //20, 10     index 1
        test.getList()[9] = (byte)0; //40, 30
        test.getList()[10] = (byte)0; //20
        test.getList()[11] = (byte)0; //40, 30
        test.getList()[12] = (byte)0; //20
        test.getList()[13] = (byte)0; //40
        test.getList()[14] = (byte)0; //20, 10 
        test.getList()[15] = (byte)30; //40, 30
        test.getList()[16] = (byte)0; //20, 10    index 2
        test.getList()[17] = (byte)0; //40, 30
        test.getList()[18] = (byte)0; //20
        test.getList()[19] = (byte)0; //40
        test.getList()[20] = (byte)0; //20, 10 
        test.getList()[21] = (byte)0; //40, 30
        test.getList()[22] = (byte)0; //20
        test.getList()[23] = (byte)20; //40
        test.getList()[24] = (byte)0; //20, 10   index 3 
        test.getList()[25] = (byte)0; //40, 30
        test.getList()[26] = (byte)0; //20
        test.getList()[27] = (byte)20; //40, 30
        test.getList()[28] = (byte)0; //20
        test.getList()[29] = (byte)0; //40
        test.getList()[30] = (byte)0; //20, 10 
        test.getList()[31] = (byte)10; //40, 30
        test.setSize(MainMemory.byteAddrFromRecNum(4));
        assertFalse(test.swap(MainMemory.byteAddrFromRecNum(2),
                MainMemory.byteAddrFromRecNum(3)));
        assertFalse(test.swap(MainMemory.byteAddrFromRecNum(2),
                MainMemory.byteAddrFromRecNum(-2)));
        assertFalse(test.swap(MainMemory.byteAddrFromRecNum(8), 0));
        assertEquals(test.getList()[3], 40);
        assertEquals(test.getList()[7], 40);
        assertTrue(test.swap(MainMemory.byteAddrFromRecNum(3), 0));
        assertEquals(test.getList()[3], 20);
        assertEquals(test.getList()[7], 10);
        assertEquals(test.getList()[27], 40);
        assertEquals(test.getList()[31], 40);
        assertTrue(test.swap(MainMemory.byteAddrFromRecNum(3),
                MainMemory.byteAddrFromRecNum(1)));
        assertEquals(test.getList()[11], 40);
        assertEquals(test.getList()[15], 40);
        assertEquals(test.getList()[27], 0);
        assertEquals(test.getList()[31], 30);
        assertTrue(test.swap(MainMemory.byteAddrFromRecNum(2), 0));
        assertEquals(test.getList()[3], 0);
        assertEquals(test.getList()[7], 20);
        assertEquals(test.getList()[19], 20);
        assertEquals(test.getList()[23], 10);
    }
    /**
     * Test method for {@link Heap#insert(byte[])}.
     */
    public void testInsert() {
        byte [] badinput = { 10, 9, 9, 7, 6, 5, 4, 3, 2, 1, 0 }; 
        byte [] badinput2 = null;
        byte [] badinput3 = { 1 };
        MainMemory test = new MainMemory();
        assertFalse(test.insert(badinput));
        assertFalse(test.insert(badinput2));
        test.setSize(MainMemory.byteAddrFromRecNum(32000));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        assertFalse(test.insert(badinput3));
        test.reset();
        assertEquals(test.getSizeBlocks(), 0);
        byte [] goodinput = new byte[4096];
        ByteBuffer buff = ByteBuffer.wrap(goodinput);
        for (int i = 0; i < 512; i++) {
            buff.putLong((long)(15 - (i % 16)));
        }
        assertEquals(buff.position(), 4096);
        for (int i = 1; i < 9; i++) {
            assertTrue(test.insert(goodinput));
            assertEquals(test.getSizeBlocks(), i);                
        } 
        assertFalse(test.insert(goodinput));
        assertEquals(test.getSizeBlocks(), 8);
        long parent = test.getListBuff().getLong(0); 
        long next = test.getListBuff().getLong(8);
        if (MainMemory.compareTo(next, parent) < 0) {
            fail("fail at count: 1 this: " 
                + Float.floatToIntBits(MainMemory.getKey(next)) + " < " 
                + Float.floatToIntBits(MainMemory.getKey(parent)));
        }
        for (int i = 2; i < 4096; i++) {
            next = test.getListBuff().getLong(i * 8);
            parent = test.getListBuff().getLong(test.parent(i * 8)); 
            if (MainMemory.compareTo(next, parent) < 0) {
                fail("fail at count: " + Integer.toString(i) + " this: " 
                    + Float.floatToIntBits(MainMemory.getKey(next)) + " < " 
                    + Float.floatToIntBits(MainMemory.getKey(parent)));
            }
        }
        
    } 
 
 
    /**
     * Test method for {@link Heap#reset()}.
     *//*
    public void testReset() {
        Heap test = new Heap();
        assertTrue(test.isEmpty());
        for(int i = 0; i < 32; i++) {
           test.buff.asLongBuffer().put(i, i); 
           System.out.println("here");
           System.out.println(i*8+7);
           test.buff.asLongBuffer().position(i);
           System.out.println(test.buff.asLongBuffer().get());
           System.out.println(i);
           assertEquals(test.getList()[i*8 + 7], i);
           assertEquals(test.buff.asLongBuffer().get(i), i);
        }
//      assertFalse(test.isEmpty());
        test.reset();
        assertTrue(test.isEmpty());
    }
    *//**
     * Test method for {@link Heap#buildHeap()}.
     */
    public void testBuildHeap() {
        MainMemory test = new MainMemory();
        //build presorted
        for (int i = 0; i < 32; i++) {
            test.getListBuff().putLong(MainMemory.byteAddrFromRecNum(i), i); 
            assertEquals(test.getList()[i * 8 + 7], i);
        }
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        test.buildHeap();
        test.reset();
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        for (int i = 1; i < 33; i += 8) {
            long parentRec = test.getListBuff().getLong(test.parent(i * 8));
            long nextRec = test.getListBuff().getLong(i * 8);
            assertTrue(MainMemory.compareTo(nextRec, parentRec) >= 0);
        }
        //build slightly out of order
        test.reset();
        for (int i = 0; i < 32; i++) {
            int j = (i % 2 == 0) ? i + 1 : i - 1;
            test.getListBuff().asLongBuffer().put(i, j); 
            assertEquals(test.getList()[i * 8 + 7], j);
        }
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        test.buildHeap();
        test.reset();
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        for (int i = 1; i < 33; i += 8) {
            long parentRec = test.getListBuff().getLong(test.parent(i * 8));
            long nextRec = test.getListBuff().getLong(i * 8);
            assertTrue(MainMemory.compareTo(nextRec, parentRec) >= 0);
        }
        //build backwards
        test.reset();
        for (int i = 0; i < 32; i++) {
            test.getListBuff().asLongBuffer().put(i, 31 - i); 
            assertEquals(test.getList()[i * 8 + 7], 31 - i);
        }
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        test.buildHeap();
        test.reset();
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        for (int i = 1; i < 33; i += 8) {
            long parentRec = test.getListBuff().getLong(test.parent(i * 8));
            long nextRec = test.getListBuff().getLong(i * 8);
            assertTrue(MainMemory.compareTo(nextRec, parentRec) >= 0);
        }
        //build out of order
        test.reset();
        for (int i = 0; i < 32; i++) {
            test.getListBuff().asLongBuffer().put(i, 31 - i + (i % 4)); 
            assertEquals(test.getList()[i * 8 + 7], 31 - i + (i % 4));
        }
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        test.buildHeap();
        test.reset();
        test.setSize(MainMemory.byteAddrFromRecNum(32));
        test.setRec(MainMemory.recNumFromByteAddr(test.getSizeMainMem()));
        for (int i = 1; i < 33; i += 8) {
            long parentRec = test.getListBuff().getLong(test.parent(i * 8));
            long nextRec = test.getListBuff().getLong(i * 8);
            assertTrue(MainMemory.compareTo(nextRec, parentRec) >= 0);
        }
    }


    /**
     * Test method for {@link Heap#darkZoneSwappage()}.
     *//*
    public void testDarkZoneSwappage() {
        Heap test = new Heap();
        //build presorted
        for(int i = 0; i < 32; i++) {
           test.buff.asLongBuffer().put(i, i); 
           assertEquals(test.getList()[i*8 + 7], i);
        }
        test.size = 32;
        assertEquals(test.buff.asLongBuffer().get(0), 0);
        assertEquals(test.buff.asLongBuffer().get(31), 31);
        
        test.darkZoneSwappage();
        assertEquals(test.buff.asLongBuffer().get(0), 31);
        assertEquals(test.buff.asLongBuffer().get(31), 0);
        assertEquals(test.getSize(), 31);

        
     }


    *//**
     * Test method for {@link MainMemory#getSizeBlocks()}.
     */
    public void testGetSizeBlocks() {
        MainMemory test = new MainMemory();
        //build presorted
        test.setSize(4096 * 8);
        assertEquals(test.getSizeBlocks(), 8);
        test.setSize(4096 * 12);
        assertEquals(test.getSizeBlocks(), 12);
        test.setSize(4093 * 12);
        assertEquals(test.getSizeBlocks(), 11);
    }
    /**
     * Test method for {@link MainMemory#parent()}.
     */
    public void testParent() {
        MainMemory test = new MainMemory();
        assertEquals(test.parent(0), -1);
        assertEquals(test.parent(test.getSize()), -1);
        for (int i = 0; i < 32; i++) {
            test.getListBuff().asLongBuffer().put(i, i); 
            assertEquals(test.getList()[i * 8 + 7], i);
        }
        test.setSize(32 * 8);
        test.setRec(32);
        assertEquals(test.parent(test.getSize() * 8), -1);
        assertEquals(test.parent(3 * 8), 1 * 8);
        assertEquals(test.parent(4 * 8), 1 * 8);
        assertEquals(test.parent(11 * 8), 5 * 8);
        assertEquals(test.parent(13 * 8), 6 * 8);
        assertEquals(test.parent(14 * 8), 6 * 8);

    }

}