/**
 * @author maden
 * Tests the valididty of our main
 * @version 1
 */
public class HeapSortTest extends student.TestCase {

    /**
     * Test method for {@link Main#main(java.lang.String[])}.
     */
    public void testheapSort() {
        String[] ourArguments = { "SyntaxTest.bin", "SyntaxStat.txt"};
        assertEquals(ourArguments[0].compareTo("SyntaxTest.bin"), 0);
        assertEquals(ourArguments[1].compareTo("SyntaxStat.txt"), 0);
        heapsort test = new heapsort();
        heapsort.main(ourArguments);
        assertNotNull(test);    
    }
}
