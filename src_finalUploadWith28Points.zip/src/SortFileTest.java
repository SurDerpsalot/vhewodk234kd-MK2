import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * @author maden, bfin96
 * unit test for the replacement method
 * @version 1
 */
public class SortFileTest extends student.TestCase {

    /**
     * Test method for {@link SortFile#SortFile(
     *  java.lang.String, java.lang.String)}.
     */
    public void testsortFile() {
        try {
            SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            assertEquals(r.getHeap().getOut().getBBuff().array().length, 4096);
        }
        catch (Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }
    /**
     * Test method for {@link SortFile#run()}.
     */
    public void testSort() {
        try {
            SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            SortFile test = new SortFile("samplein\\16Blocks.bin",
                    "a1.bin", "a2.bin", "a3.bin");
            assertEquals(r.getHeap().getListBuff().capacity(), 
                    (long)(4096 * 8));
            r.sort();
            assertEquals(r.getRo().length(), r.getIo().length());
            test.sort();
        }
        catch (Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }

    /**
     * Test method for {@link SortFile#initialSort()}.
     */
    public void testCountRuns() {
        try {
            ArrayList<Integer> temp = new ArrayList<Integer>();
            SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            RandomAccessFile blocks8  = 
                    new RandomAccessFile("samplein\\8Blocks.bin", "rw");
            temp = r.countRuns(blocks8);
            assertEquals(temp.size(), 1);
            assertEquals(temp.get(0).intValue(), 8);
            RandomAccessFile blocks16  = 
                    new RandomAccessFile("samplein\\16Blocks.bin", "rw");
            temp = r.countRuns(blocks16);
            assertEquals(temp.size(), 2);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            RandomAccessFile blocks32  = 
                    new RandomAccessFile("samplein\\32Blocks.bin", "rw");
            temp = r.countRuns(blocks32);            
            assertEquals(temp.size(), 4);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            assertEquals(temp.get(2).intValue(), 8);
            assertEquals(temp.get(3).intValue(), 8);
            RandomAccessFile blocks64  = 
                    new RandomAccessFile("samplein\\64Blocks.bin", "rw");
            temp = r.countRuns(blocks64);            
            assertEquals(temp.size(), 8);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            assertEquals(temp.get(2).intValue(), 8);
            assertEquals(temp.get(3).intValue(), 8);
            assertEquals(temp.get(4).intValue(), 8);
            assertEquals(temp.get(5).intValue(), 8);
            assertEquals(temp.get(6).intValue(), 8);
            assertEquals(temp.get(7).intValue(), 8);
            RandomAccessFile blocks6 = 
                    new RandomAccessFile("samplein\\6Blocks.bin", "rw");
            temp = r.countRuns(blocks6);            
            assertNull(temp);
        } 
        catch (FileNotFoundException e) {
            // ToDo Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    /**
     * Test method for {@link SortFile#initialSort()}.
     */
    public void testCountRuns2() {
        SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
        ArrayList<Integer> previousRuns = new ArrayList<Integer>();
        ArrayList<Integer> nextRuns;
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 1);
        assertEquals(nextRuns.get(0).intValue(), 64);
        previousRuns.add(8);
        assertEquals(previousRuns.size(), 9);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 2);
        assertEquals(nextRuns.get(0).intValue(), 64);
        assertEquals(nextRuns.get(1).intValue(), 8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 2);
        assertEquals(nextRuns.get(0).intValue(), 64);
        assertEquals(nextRuns.get(1).intValue(), 64);
        nextRuns = r.countRuns(nextRuns);
        assertEquals(nextRuns.size(), 1);
        assertEquals(nextRuns.get(0).intValue(), 128);
        int totalBlocks = 0;
        for (int i = 0; i < previousRuns.size(); i++) {
            totalBlocks += previousRuns.get(i).intValue();
        }
        assertEquals(totalBlocks, 128);
    }
    /**
     * Test method for {@link SortFile#initialSort()}.
     */
    public void testInitialSort() {
        try {
            SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            int blockRead = 0;
            r.setRunBlockCountList(r.countRuns(r.getIo()));
            r.setRuns(r.getRunBlockCountList().size());
            assertEquals(r.getRuns(), 1);
            while (blockRead < r.getRuns()) {
                //reads in the number of blocks expected for this run
                try {
                    for (int i = 0; i < 8; i++) {
                        r.getHeap().getIn().getBBuff().clear();
                        assertEquals(r.getHeap().getIn().getBuff().length,
                                4096);
                        r.getIo().readFully(r.getHeap().getIn().getBuff());
                        r.getHeap().getIn().addBlock();
                        //ToDo: add a block to the heap
                        r.getHeap().insert(r.getHeap().getIn().popBlock());
                        System.out.println("root");
                        System.out.println(MainMemory.getKey(
                                r.getHeap().getListBuff().getLong(0)));
                        System.out.println(MainMemory.getKey(
                                r.getHeap().getListBuff().getLong(
                                        r.getHeap().getSizeMainMem() - 9)));
                    }

                    //test the output
                    int j = 0;
                    long prevRecord = -1;
                    long nextRecord = -1;
                    ByteBuffer b = ByteBuffer.allocate(4096);
                    while (j < 8) {
                        b = r.getHeap().popMinBlock().getBBuff();
                        nextRecord = b.getLong(0);
                        b.position(0);
                        int pos = 0;
                        if (j == 0) { prevRecord = nextRecord; }
                        while (b.hasRemaining()) {
                            assertTrue(MainMemory.compareTo(
                                    prevRecord, nextRecord) <= 0);
                            nextRecord = b.getLong();
                            pos += 8;
                            prevRecord = r.getHeap().parent(pos);
                            
                        }
                        assertEquals(b.position(), 4096);
                        j++;
                
                    } 
                }
                catch (IOException e) {
                    // ToDo Auto-generated catch block
                    e.printStackTrace();
                    fail("poor compilation");
                }
                //test the output to the runfile
                blockRead++; //add the next block
            }
        }
        catch (Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }

    /**
     * Test method for {@link SortFile#compareTo(long, long)}.
     */
    public void testCompareTo() {
        float w = 10.0f;
        float e = 12.0f;
        float q = -30.5f;
        assertTrue(Float.compare(w, e) < 0);
        assertTrue(Float.compare(w, q) > 0);
        assertEquals(Float.compare(q, q), 0);
        
        byte[] test = new byte[16];
        test[0] = (byte)1; //20, 10 
        test[1] = (byte)2; //40, 30
        test[2] = (byte)3; //20
        test[3] = (byte)4; //40
        test[4] = (byte)5; //20, 10 
        test[5] = (byte)6; //40, 30
        test[6] = (byte)7; //20
        test[7] = (byte)8; //40
        test[8] = (byte)1; //20, 10 
        test[9] = (byte)2; //40, 30
        test[10] = (byte)3; //20
        test[11] = (byte)4; //40, 30
        test[12] = (byte)0; //20
        test[13] = (byte)0; //40
        test[14] = (byte)0; //20, 10 
        test[15] = (byte)0; //40, 30
        ByteBuffer buff = ByteBuffer.wrap(test);
        assertTrue(SortFile.compareTo(buff.getLong(0), buff.getLong(8)) > 0);
        test[12] = (byte)5; //20
        test[13] = (byte)6; //40
        test[14] = (byte)7; //20, 10 
        test[15] = (byte)8; //40, 30
        assertEquals(SortFile.compareTo(buff.getLong(0), buff.getLong(8)), 0);
    }
    /**
     * Test method for the pushBlock function of the DataBuffer and the
     * getRecord function of the DataBuffer.
     */
    public void testDataBuffer() {
        SortFile r = new SortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
        byte [] block = new byte[4096];
        block[0] = (byte)1;
        block[1] = (byte)2;
        block[2] = (byte)3;
        block[3] = (byte)4;
        block[4] = (byte)5;
        block[5] = (byte)6;
        block[6] = (byte)7;
        block[7] = (byte)8;
        block[8] = (byte)1;
        block[9] = (byte)2;
        block[10] = (byte)3;
        block[11] = (byte)4;
        block[12] = (byte)5;
        block[13] = (byte)6;
        block[14] = (byte)7;
        block[15] = (byte)8;
        ByteBuffer buff = ByteBuffer.wrap(block);
        r.getHeap().getIn().pushBlock(block);
        byte[] fail = new byte[20];
        assertFalse(r.getHeap().getIn().pushBlock(fail));
        assertEquals(SortFile.compareTo(
                r.getHeap().getIn().getBBuff().getLong(0), buff.getLong(0)), 0);
        long test = 0;
        test = r.getHeap().getIn().getRecord(0);
        assertEquals(SortFile.compareTo(test, buff.getLong(8)), 0);
    }

}
