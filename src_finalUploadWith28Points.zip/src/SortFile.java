import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
/**
 * This is the class used for replacement selection
 * @author bfin96, m1newc
 * @version 1.4
 */
public class SortFile {
    /**
     * A static declaration of the number of bytes in a block
     */
    public static final int BLOCK_BYTES = 4096;
    /**
     * A static declaration of the number of bytes in a record
     */
    public static final int RECORD_BYTES = 8;
    /**
     * The number of runs to export in the next external sort
     */
    private int numberOfRuns;
    /**
     * lengths of each run saved in blocks
     */
    private ArrayList<Integer> runBlockCountList;
    /**
     * retrieves the RunBlockCountList
     * @return the RunBlockCountList
     */
    public ArrayList<Integer> getRunBlockCountList() {
        return runBlockCountList;
    }
    /**
     * sets the RunBlockCountList
     * @param in the new ArrayList that will replace RunBlockCountList
     */
    public void setRunBlockCountList(ArrayList<Integer> in) {
        runBlockCountList = in;
    }
    /**
     * positions to read in the heap
     */
    private ArrayList<Integer> positionsList; 
    /**
     * The heap
     */
    private MainMemory mainMem;
    /**
     * retrieves the heap
     * @return the heap
     */
    public MainMemory getHeap() {
        return mainMem;
    }
    /**
     * The file that will be sorted
     */
    private RandomAccessFile ioRaf;
    /**
     * retrieves the RandomAccessFile for the input file
     * @return the RandomAccessFile for the input file
     */
    public RandomAccessFile getIo() {
        return ioRaf;
    }
    /**
     * The file that the sorted values will be output to
     */
    private RandomAccessFile runRaf;
    /**
     * retrieves the RandomAccessFile for the Run File
     * @return the RandomAccessFile for the Run File
     */
    public RandomAccessFile getRo() {
        return runRaf;
    }
    
    /**
     * The statistics file that will be printed to at the end
     */
    private RandomAccessFile statRaf;
    /**
     * The constructor for the ReplacementSort
     * @param inputFile the file to read bytes from
     * @param runFile the file where the first sorting run of the file goes
     * @param run2File the second temporary file used to sort runs
     * @param statFile the statistics file
     */
    public SortFile(String inputFile, String runFile,
            String run2File, String statFile) { 
        //resetPositionsList(8);   //<-- This was giving an error
        mainMem = new MainMemory(positionsList);
        mainMem.setIn(new DataBuffer(BLOCK_BYTES));
        mainMem.setOut(new DataBuffer(BLOCK_BYTES));
        //runLength = new ArrayList<Integer>();
        /**
         * The second run file 
         */
        RandomAccessFile run2Raf;
        try {
            ioRaf = new RandomAccessFile(inputFile, "rw");
            runRaf = new RandomAccessFile(runFile, "rw");
            run2Raf = new RandomAccessFile(run2File, "rw");
            statRaf = new RandomAccessFile(statFile, "rw");
            clearRAF(runRaf);
            clearRAF(run2Raf);            
        }
        catch (FileNotFoundException e) {
            System.err.println("Could not find file.");
        } 
    }
    /**
     * sets the number of runs
     * @param set is the number of runs
     */
    public void setRuns(int set) {
        numberOfRuns = set;
    }
    /**
     * gets the number of runs
     * @return the number of runs
     */
    public int getRuns() {
        return numberOfRuns;
    }
    
    
    
    /**
     * resets the positionsList to point to only the first element of each block
     * @param positions is the number of blocks to reference
     
    private void resetPositionsList(int positions){
        positionsList.clear();
        for(int i = 0; i < positions; i++) {
           positionsList.add(0); 
        }
        mainMem.positions = positionsList;
    }
    */
    /**
     * return an array that is the length of the expected number of 
     * runs in order to sort this file. The elements of the output array
     * are the number of blocks that will be processed in each run.
     * @param raf is the file to check
     * @return a list of integers
     */
    protected ArrayList<Integer> countRuns(RandomAccessFile raf) {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        try {
            if (raf.length() % (BLOCK_BYTES * 8) != 0) {
                return null;
            }
            int numberOfBlocksInRAF = (int) (raf.length() / BLOCK_BYTES);
            //N is the number of runs that will be created given the 
            //number of blocks in the RAF
             
            while (numberOfBlocksInRAF > 8) {
                temp.add(8);
                numberOfBlocksInRAF -= 8;
            }
            temp.add(numberOfBlocksInRAF);
            return temp;
        } 
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    /**
     * for all subsequent runs, you can find their next sizes using the 
     * previous one
     * @param givenRuns an array of the lengths of the previous runs
     * @return the expected lengths of your next set of runs in blocks
     */
    protected ArrayList<Integer> countRuns(ArrayList<Integer> givenRuns) {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        int numberOfRunsGiven = givenRuns.size();
        //N is the number of runs that will be created given the 
        //number of blocks in the RAF
        int i = 0;
        int j = -1;
        while (i < numberOfRunsGiven) {
            if (i % 8 == 0) {
                j++;
                temp.add(givenRuns.get(i));
            }
            else {
                temp.set(j, temp.get(j) + givenRuns.get(i));                    
            }
            i++;
        }
        return temp;
    } 
    /**
     * @param record is the 16-byte number with a value-key pair
     * @return float key is the LSB 4-bytes from the long
     */
    public static float getKey(long record) {
        byte[] test = new byte[8];
        ByteBuffer buff = ByteBuffer.wrap(test);
        buff.putLong(record);
        return buff.getFloat(4);
    }
    /**
     * @param record is the 16-byte number with a value-key pair
     * @return unsigned int value is the MSB 4-bytes from the long
     */
    public static long getValue(long record) {
        return (long)(record >>> 32); //logical shift right
    }
    /**
     * clears a specified RandomAccessFile
     * @param raf the file to clear
     */
    void clearRAF(RandomAccessFile raf) {
        try {
            raf.setLength(0);
        }
        catch (Exception e) {
            System.err.println("Could not clear file.");    
        }
    }
    /**
     * This is the first run which will quicksort blocks of the inputFile
     * @return true if executed successfully
     */
    public boolean initialRun() {
        int blockRead = 0;
        while (blockRead < numberOfRuns) {
            //reads in the number of blocks expected for this run
            for (int i = 0; i < 8; i++) {
                try {
                    mainMem.getIn().getBBuff().clear();
                    ioRaf.readFully(mainMem.getIn().getBuff());
                    mainMem.getIn().addBlock();
                    mainMem.insert(mainMem.getIn().popBlock());
                    System.out.println("root");
                    System.out.println(getKey(
                            mainMem.getListBuff().getLong(0)));
                    System.out.println(getKey(mainMem.getListBuff().getLong(
                            mainMem.getSizeMainMem() - 9)));
                } 
                catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            }
            sendInitialRunToRunFile(8); 
            blockRead++; //add the next block
            mainMem.getListBuff().clear();
        }
        return true;
    }
   /**
    * sends the smallest values in the main memory to the run file.
    * The values are sorted in ascending order 
    * @param blocks the number of blocks to pull
    */
    protected void sendInitialRunToRunFile(int blocks) {
        int i = 0;
        try {
            while (i < blocks) {
                runRaf.write(mainMem.popMinBlock().getBuff());
                i++;
            }
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }
   /**
    * This is the main algorithm for running this entire system of sorting
    * @return the execution time of the sort
    */
    public long sort() {
        long stop = 0;
        long lastExecTime = -2;
        long start = System.currentTimeMillis();
        runBlockCountList = countRuns(ioRaf);
        numberOfRuns = runBlockCountList.size();
        //import all the data from the input file
        //it will organize the blocks of data into N runs, 
        //where N is the number of 8*blockbytesize chunks in the input file.
        initialRun();
        //everything is now in the runFile.  
        //until the number of merges satisfies the requirement to sort the 
        //entire file, it will pass data back an forth between the two runfiles
        boolean inRun2Final = (numberOfRuns % 2 == 0);
        int i = 0;
        while (numberOfRuns > 1) {
            //resetPositionsList(8);
            while (i < numberOfRuns) {
                //ToDo: initialize run start positions. 
                //Get rid of global numberOfRuns
                //ToDo: mergesort while exporting to the oppositerunfile
                if (i % 2 == 0) {
                    //positions = mergesort(runRaf, run2Raf);
                    inRun2Final = true;
                }
                else {
                    //positions = mergesort(runRaf, runRaf);
                    if (inRun2Final) {
                        inRun2Final = false;
                    }
                }
                i++;
            }
            //next number of runs to be expected. 
            //When there is only one run, it is the final one
            runBlockCountList = countRuns(runBlockCountList);
            numberOfRuns = runBlockCountList.size(); 
        }
        //post-processing
/*        if(inRun2Final) {
            saveInTheInputFile(ioRaf, run2Raf);
        }
        else {
            saveInTheInputFile(ioRaf, runRaf);
        }
*/        
        stop = System.currentTimeMillis();
        lastExecTime = stop - start;
        return lastExecTime;
    }
    /**
     * saving an entry in the statistics file
     * @param execTime this is the execution time
     * @param statName the name of the statistics file
     * @return true if successful
     */
    protected boolean saveInTheStatisticsFile(long execTime, 
            String statName) {
        try {
            statRaf.writeBytes(String.format("%l %s\n", execTime, statName));
            return true;
        }
        catch (Exception e) {
            System.err.println("Printing Error: " + e.toString());
        }
        return false;
        
    }
    /**
     * saves in the user-specified file, the result, and 
     * prints to the system every block's first element
     * @param outRaf where to save
     * @param rRaf what to save
     * @return true if successfully completed
     */
    protected boolean saveInTheInputFile(RandomAccessFile outRaf, 
        RandomAccessFile rRaf) {
        try {
            outRaf.setLength(0);
            long recordLong;
            long recordValue;
            float recordKey;
            int numberOfEntries = (int)(rRaf.length() / 4096);
            for (int i = 0; i < numberOfEntries; i++) {
                //ToDo: see if I need to update the file pointer, 
                //or if it does that automatically
                rRaf.readFully(mainMem.getIn().getBuff(),
                        i * BLOCK_BYTES, BLOCK_BYTES);
                mainMem.getIn().addBlock();
                recordLong = mainMem.getIn().getRecord(0);
                recordKey = getKey(recordLong);
                recordValue = getValue(recordLong);
                outRaf.write(mainMem.getIn().popBlock());
                if (i % 5 != 4) {
                    System.out.format("%l %f ", recordValue, recordKey);
                }
                else {
                    System.out.format("%l %f\n", recordValue, recordKey);
                }
            }
            return true;
        }
        catch (Exception e) {
            System.err.println("Printing Error: " + e.toString());
        }
        return false;
        
    }
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    
    /**
     * This function compares two key values against each other and returns
     * a positive if A > B, negative if A < B, and 0 if A = B.
     * It also compares integers if the keys are the same.
     * @param a the first record to be compared
     * @param b the second record to be compared
     * @return the positive, negative, or 0 result of their subtraction.
     */
    public static int compareTo(long a, long b) {
        float aF = getKey(a);
        float bF = getKey(b);
        long aI = getValue(a);
        long bI = getValue(b);
        return (Float.compare(aF, bF) != 0 ) ? Float.compare(aF, bF) :
            Long.compare(aI, bI);   
    }
}
