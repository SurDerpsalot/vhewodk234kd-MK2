import java.nio.ByteBuffer;

//import java.io.PrintWriter;
/**
 * This contains our input and output buffers
 * @author Madelyn Newcomb m1newc, Bradley Finagin bfin96
 * @version 1
 *
 */
public class DataBuffer {
    //private array of blocks to act as memory
    //private long lastExecTime; 
    /**
     * This is where the block size is stored
     */
    private int blockSize;
    /**
     * This holds the fill size
     */
    private int blockFillSize;
    /**
     * this is the bytebuffer that is going to be wrapped
     */
    private byte[] buff;   
    /**
     * This is the bytebuffer that will be used instead of the byte array
     */
    private ByteBuffer inBuff;
    /**
     * retrieves the byte array for editing
     * @return the byte array for editing
     */
    public byte[] getBuff() {
        return buff;
    }
    /**
     * retrieves the byteBuffer for editing
     * @return the byteBuffer for editing
     */
    public ByteBuffer getBBuff() {
        return inBuff;
    }    
    /**
     * constructor
     * @param size this is the size of the block being created
     */
    public DataBuffer(int size) {
        blockSize = size; //size in bytes of a block, and the buffer
        blockFillSize = 0;
        buff = new byte[size];
        inBuff = ByteBuffer.wrap(buff);
  //      lastExecTime = -1;
    }
    /**
     * increments the filled space based by a block
     */
    public void addBlock() {
        blockFillSize += blockSize;        
    }
    /**
     * pushes a block of data into this buffer space
     * @param block the input data
     * @return true if the block was pushed correctly
     */
    public boolean pushBlock(byte[] block) {
        if (block.length != blockSize) {
            return false;
        }
        blockFillSize += blockSize;
        inBuff.clear();
        inBuff.put(block);
        return true;
    }
    /**
     * pops an entire block of data
     * @return the block stored in the buffer
     */
    public byte[] popBlock() {
        blockFillSize -= blockSize;
        return inBuff.array();
    }
    /**
     * given a position in the buffer, returns a record
     * @param record is the record location in the buffer
     * @return the record stored in the buffer
     */
    public long getRecord(int record) {
        return inBuff.getLong((record * 8));
    }
}
