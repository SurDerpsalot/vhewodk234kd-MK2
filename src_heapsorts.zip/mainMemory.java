import java.nio.ByteBuffer;
import java.util.ArrayList;
//import java.nio.LongBuffer;
/**
 * class for our heap structure
 * @author bfin96, maden
 *
 */
public class mainMemory {
	public int darkzone; //number of completely sorted values
	public int lightzone; //number of unsorted positions
	protected int records; //number of records in the heap
	protected int size; //number of bytes used in the heap (records*8)
	public byte[] list; //heap storage
	public ByteBuffer buff; //byte buffer wrapped to the list
    protected DataBuffer inputBuffer;
    protected DataBuffer outputBuffer;

    ArrayList<Integer> positions; //list of reading positions in the heap
//    ArrayList<ArrayList<Integer>> smallestValues; //use insertion sort to save the comparisons in order to make the search faster
	//I don't know if this would help and make things easier to read
	//public LongBuffer longBuff = LongBuffer.wrap(buff.asLongBuffer().array());
	/**
	 * constructor
	 */
    public mainMemory()
    {
    	list = new byte[32768];
		size = 0;
		records = 0;
		darkzone = 0;
		lightzone = 32767;
		buff = ByteBuffer.wrap(list);
    }
	public mainMemory(ArrayList<Integer> pos) {
		list = new byte[32768];
		size = 0;
		records = 0;
		darkzone = 0;
		lightzone = 32767;
		buff = ByteBuffer.wrap(list);
		positions = pos;
    }
	/**
	 * insert an array of bytes into the heap
	 * @param items the array of bytes
	 */
    public boolean insert(byte[] items) {
        if(items == null) {
            return false;
        }
    	if(items.length % 4096 != 0) {
    	    return false; //not a block
    	}
    	if(size + items.length > 4096*8) {
    	    return false; //out of bounds
    	}
    	ByteBuffer it = ByteBuffer.wrap(items);
    	if(size == 0) { //first item
        	buff.putLong(it.getLong());
    		records = records+1;
    		size = size + 8;
		}
    	while(it.hasRemaining())
    	{
    		buff.putLong(it.getLong());
    		minHeapify(size);
    		records = records+1;
    		size = size + 8;
    		
    	}
    	return true;
    }
    /**
     * quickly sorts the main memory
     */
    public void quickSort() {
    	//System.out.println("butts");
    }
    /**
     * resets the size of the heap, as well as the sorted region.
     * It heapifies.
     */
    public void reset(){
        buff.clear();
    	size = 0;
    	records = 0;
    	darkzone = 0;
        lightzone = 32767;
    }
    /**
     * build a minHeap
     */
    public void buildHeap() {
        int s = records;
        while (s > 0)
        {
        	swap(s-1, 0);
        	s = s - 1;
        	minHeapify(byteAddrFromRecNum(s));
        }
	}
   /** @param record is the 16-byte number with a value-key pair
    * @return float key is the LSB 4-bytes from the long
    */
   public static float getKey(long record) {
	   byte[] test = new byte[8];
	   ByteBuffer buff = ByteBuffer.wrap(test);
	   buff.putLong(record);
       return buff.getFloat(4);
   }
   /**
    * @param record is the 16-byte number with a value-key pair
    * @return unsigned int value is the MSB 4-bytes from the long
    */
   public static long getValue(long record) {
       return (long)(record >>> 32); //logical shift right
   }
    /**
     * overloads the compareTo function to include long number comparisons
     * @param a first long number for comparison
     * @param b second long number for comparison
     * @return 0 if they are the same. A positive number if
     * a follows b, and a negative number if b precedes a.
     */
    public static int compareTo(long a, long b) {
    	float aF = getKey(a);
    	float bF = getKey(b);
    	long aI = getValue(a);
    	long bI = getValue(b);
    	return (Float.compare(aF, bF) != 0 ) ? Float.compare(aF, bF) : Long.compare(aI, bI);
    	
    }
    /**
     * get the record number
     * @param bNum byte address of the start for your long
     * @return return the corresponding record number
     */
    public static int recNumFromByteAddr(int bNum) {
    	return bNum/8;
    }
    /**
     * get the record number
     * @param rNum record number of your long
     * @return return the corresponding byte address 
     * for the start of your number
     */
    public static int byteAddrFromRecNum(int rNum) {
    	return rNum*8;
    }
    /**
     * build a level for a minHeap
     * @param i the current byte address for the start of the long value 
     * in the heap. 
     * It is the start of the next Long address
     */
    private void minHeapify(int i) {
    	int p = parent(i);
        if(p >= 0 && compareTo(buff.getLong(p), buff.getLong(i)) > 0 )
        {
        	swap(i, p);
        	minHeapify(p);
        }
    }
    
    
    /**
     * check if the heap is empty
     * TODO: validate that this logic is correct.
     * @return
     */
    public boolean isEmpty() {
        return (end() < 0) || buff.asLongBuffer().hasRemaining();
    }
    /**
     * get the number of bytes 
     * @return get the number of records
     */
    public int getSize() {
    	return size;
    }
    /**
     * get the number of blocks in this heap
     * @return
     */
    public int getSizeBlocks() {
    	return size/4096;
    }
    /**
     * get the right child of pos i
     * @param i current position
     * @return the right child int
     */
    private int right(int i) {
        return (2 * i + 2) * 8;
    }
    /**
     * end of the region used to heapify. the value after the 
     * end() will be the maximum value in the darkzone
     * @return size - 1
     */
    private int end() {
        return size - 8;
    }
    /**
     * return the parent to a position in the heap
     * @param i the current position's byte address
     * @return the parent's byte address. If out of bounds, this will return -1
     */
    protected int parent(int i) {
    	int j = recNumFromByteAddr(i);
        if(j < 1 || j > records || i % 8 != 0) {
            return -1;
        }
        return (j % 2 == 0) ? byteAddrFromRecNum((j - 1) / 2) : byteAddrFromRecNum(j / 2);
    }
    /**
     * get the position of the left child
     * @param i current position
     * @return the left child int
     */
    private int left(int i) {
        return (2 * i + 1) * 8;
    }
    /**
     * swap the current position with its parent
     * @param i current byte address
     * @param parent the parent of i
     * @return if swap was successful
     */
	protected Boolean swap(int i, int parent) {
	    if(parent < i && parent >= 0 && i <= size) {
            long temp = buff.getLong(parent);
          //  System.out.println(buff.asLongBuffer().get(parent));
            //System.out.println(buff.asLongBuffer().get(i));
            buff.putLong(parent, buff.getLong(i));
            buff.putLong(i, temp);
            return true;
	    }
	    return false;
    }
	
	
	/////////////////////////////////////
    /////////////////////////////////////
    /////////////////////////////////////
    /////////////////////////////////////
	/**
	 * 
	 * @param positions a list of the record position to read from
	 * @return the minimum value at the front of each block in main memory
	 * that is identifies by the last position popped from the front
	 *//*
	protected long mainMemSmallestValue() {
	    int smallestBlock = -1;
	    long smallestValue, tempValue;
	    smallestValue = (long)((0xFFFFFFFF << 32) | 0xFFFFFFFF);
	    for (int i = 1; i < 8; i++) {
	        if (positions.get(i) < 512) { //block has space
	            tempValue = buff.asLongBuffer().get(positions.get(i) + i*512);
	            if(compareTo(tempValue, smallestValue) <= 0) { 
	                smallestValue = tempValue;
	                smallestBlock = i;
	            }
	        }
	    }
	    //pop the smallest value by moving to the next position in its block
	    positions.set(smallestBlock, positions.get(smallestBlock) + 1);
	    return smallestValue;
	}
	*/
    /**
     * returns the first block number that is all used in the main memory heap
     * @return
     */
    public int getEmptyBlock() {
        for (int i = 0; i < 8; i++) {
            if (positions.get(i) > 4095) {
                return i;
            }
        }
        return -1;
    }
	    
	/**
	 * when the caller of this class updates the positions
	 * @param pos the new data for positionsList
	 */
	protected void updatePositions(ArrayList<Integer> pos) {
	    positions = pos;
	}
	
	/**
	 * get the next block of data from the heap-sorted memory
	 * @return the output buffer with the block of minimum values
	 */
	protected DataBuffer popMinBlock() {
	    outputBuffer.inBuff.clear();
	    for(int i = 0; i < 512; i++) {
	        outputBuffer.inBuff.putLong(popMinRecord());
	    }
	    return outputBuffer;
	}
	/**
	 * returns the smallest value in the heap, and updates its structure
	 * @return the smallest value in the heap
	 */
	private long popMinRecord() {
        swap(end(),0);
        size = end(); 
        records--;
        shrinkHeap(0);
	    return buff.getLong(size);
	}
	/**
	 * shrink the heap by one level
	 * @param i the current byte address for the start of the long value 
	 * in the heap. 
	 * It is the start of the next Long address
	 */
	private void shrinkHeap(int i) {
	    if(i > size) { return; }
	    if (left(i) > size) { return; }
	    long left = buff.getLong(left(i));
	    long right = buff.getLong(right(i));
	    long curr = buff.getLong(0);
	    int smallestpos = i;
	    if(compareTo(curr, left) > 0 ) {
	        smallestpos = left(i);
	        curr = left;
	    }
	    if(compareTo(curr, right) > 0 ) {
	        smallestpos = right(i);
	        curr = right;
	    }
	    if(smallestpos != i) {
	        swap(smallestpos, i);
	        shrinkHeap(smallestpos);
	    }
	}
}
