import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

//import java.io.PrintWriter;

public class DataBufferSort {
	//private array of blocks to act as memory
    private long lastExecTime;
   
    protected byte[] hmIn;   
    protected ByteBuffer inBuff;
    protected byte[] hmOut;
    protected ByteBuffer outBuff;
    /**
     * constructor
     */
    public DataBufferSort() {
    	hmIn = new byte[4096];
        hmOut = new byte[4096];
        inBuff = ByteBuffer.wrap(hmIn);
        outBuff = ByteBuffer.wrap(hmOut);
        lastExecTime = -1;
    }
    /**
     * Runs the heap sort of the buffer data
     * @return a long value representing the exec time
     */
    long runHeapSort(){
        lastExecTime = -2;
        long stop = 0;
        long start = System.currentTimeMillis();
       // heapSort();
        stop = System.currentTimeMillis();
        lastExecTime = stop - start;
        return lastExecTime;
    };
	
}
