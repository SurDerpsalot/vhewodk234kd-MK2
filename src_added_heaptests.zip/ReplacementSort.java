import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
/**
 * This is the class used for replacement selection
 * @author bfin96, m1newc
 *
 */
public class ReplacementSort {
	int BLOCK_BYTES = 4096;
	int RECORD_BYTES = 8;
	private Heap theHeap;
	private RandomAccessFile raf; 
	private RandomAccessFile outRaf;
	private DataBufferSort dbs;
	//since the runs can end with an incomplete block, 
	//the length is in records not in blocks
	private ArrayList<Integer> runLength;
	/**
	 * The constructor for the ReplacementSort
	 * @param inputFile the file to read bytes from
	 * @param runFile the file where the replacement selection results go
	 */
	public ReplacementSort(String inputFile, String runFile) { 
		dbs = new DataBufferSort();
		theHeap = new Heap();
		runLength = new ArrayList<Integer>();
		try {
		    raf = new RandomAccessFile(inputFile, "rw");
		    outRaf = new RandomAccessFile(runFile, "rw");
		}
		catch (FileNotFoundException e) {
			System.err.println("Could not file file:" );
		} 
	}	
	/**
	 * This function check the file for proper styling input
	 * and then fills up the heap. It then will do a run per iteration
	 * of the while loop until there is no more input.
	 */
	public void run() {
		try {
            if (raf.length() % (8 * BLOCK_BYTES) != 0 ) {
                System.out.println("Error: bad file length");
                return;
            }
            //long numberOfBlocks = raf.length() / (BLOCK_BYTES);
            fillTheHeap();
            raf.readFully(dbs.hmIn);
            while(!theHeap.isEmpty()){
            	outTheHeap();
            	resetTheHeap();
            }
            System.out.println("The number of blocks is: " + (raf.length()/BLOCK_BYTES));
			
		} 
		catch (IOException e) {
			System.err.println("Writing error: " + e);
		}
	}
	
	/**
	 * This function fills the heap with its full 8 blocks.
	 */
	public void fillTheHeap()
	{
		while(theHeap.getSize() < 4096){
			try{
				raf.readFully(dbs.hmIn);
				theHeap.insert(dbs.inBuff.array());
				dbs.inBuff.clear();
			}
			catch (IOException e) {
		        System.err.println("Writing error: " + e);
			}
		}
	}
	
	/**
	 * This function runs the replacement sort algorithm and writes
	 * to the output buffer. When the output buffer is full it outputs
	 * to the run file
	 */
	public void outTheHeap(){
		dbs.outBuff.clear();
		dbs.outBuff.putLong(theHeap.buff.getLong(0));
		theHeap.buff.putLong(dbs.inBuff.getLong());
		theHeap.buildHeap();
		int i = 0;
		int length = 0;
		while(theHeap.darkzone < 4096)
		{
			//if the smallest element in the heap is smaller than the largest 
			//value in the output buffer
			if(compareTo(theHeap.buff.getLong(0), dbs.outBuff.getLong(i)) < 0)
			{
				//rebuilds the tree *hopefully* like it do in replacement sort
				theHeap.darkZoneSwappage();
			}
			else
			{
				dbs.outBuff.putLong(theHeap.buff.getLong(0));
				i = i+1;
				if(!dbs.inBuff.hasRemaining())
				{
					dbs.inBuff.clear();
					try {
						raf.readFully(dbs.hmIn);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				theHeap.buff.putLong(0, dbs.inBuff.getLong());
				theHeap.buildHeap();
				length = length + 1;
				if(!dbs.outBuff.hasRemaining())
				{
					try {
						outRaf.write(dbs.hmOut);
					} catch (IOException e) {
						e.printStackTrace();
					}
					dbs.outBuff.clear();
				}
			}
		}
		//run is now over. put out the end of run item (float of -1) and
		//add the length of the run to the array.
		runLength.add(length);
		dbs.outBuff.putLong(-1);
		try {
			outRaf.write(dbs.hmOut);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This function resets the heap after the darkzone has claimed the 
	 * entire heap, ending a run.
	 */
	public void resetTheHeap() {
		theHeap.reset();
	}
	
	
	/**
	 * This function compares two key values against each other and returns
	 * a positive if A > B, negative if A < B, and 0 if A = B.
	 * It also compares integers if the keys are the same.
	 * @param a the first record to be compared
	 * @param b the second record to be compared
	 * @return the positive, negative, or 0 result of their subtraction.
	 */
	public static int compareTo(long a, long b) {
	    	float aF = (a << 32) >> 32;
	    	float bF = (b << 32) >> 32;
	    	if(aF-bF == 0)
	    	{
	    		int aI = (int) (a>>32);
	    		int bI = (int) (b>>32);
	    		if(aI-bI == 0)
	    		{
	    			return 0;
	    		}
	    		else
	    		{
	    			return aI-bI;
	    		}
	    	}
	    	else
	    	{
	    		return (int) (aF-bF);
	    	}
	    }
}
