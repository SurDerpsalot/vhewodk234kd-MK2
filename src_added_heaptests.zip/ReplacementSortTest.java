/**
 * @author maden
 * unit test for the replacement method
 */
public class ReplacementSortTest extends student.TestCase {

    /**
     * Test method for {@link ReplacementSort#ReplacementSort(
     *  java.lang.String, java.lang.String)}.
     */
    public void testReplacementSort() {
        try {
            ReplacementSort r = new ReplacementSort("SyntaxTest.bin", "run.txt");
        }
        catch(Exception e) {
            fail("could not build");
        }
    }

    /**
     * Test method for {@link ReplacementSort#run()}.
     */
    public void testRun() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link ReplacementSort#fillTheHeap()}.
     */
    public void testFillTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link ReplacementSort#outTheHeap()}.
     */
    public void testOutTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link ReplacementSort#resetTheHeap()}.
     */
    public void testResetTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link ReplacementSort#compareTo(long, long)}.
     */
    public void testCompareTo() {
        fail("Not yet implemented");
    }

}
