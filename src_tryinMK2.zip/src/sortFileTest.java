import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;

/**
 * @author maden
 * unit test for the replacement method
 */
public class sortFileTest extends student.TestCase {

    /**
     * Test method for {@link sortFile#sortFile(
     *  java.lang.String, java.lang.String)}.
     */
    public void testsortFile() {
        try {
            sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
        }
        catch(Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }
    /**
     * Test method for {@link sortFile#run()}.
     */
    public void testSort() {
        try {
            sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            sortFile test = new sortFile("samplein\\16Blocks.bin", "a1.bin", "a2.bin", "a3.bin");
            assertEquals(r.mainMem.buff.capacity(), (long)(4096*8));
            r.sort();
            assertEquals(r.runRaf.length(), r.ioRaf.length());
            test.sort();
        }
        catch(Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }

    /**
     * Test method for {@link sortFile#initialSort()}.
     */
    public void testCountRuns() {
        try {
            ArrayList<Integer> temp = new ArrayList<Integer>();
            sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            RandomAccessFile blocks8  = new RandomAccessFile("samplein\\8Blocks.bin", "rw");
            temp = r.countRuns(blocks8);
            assertEquals(temp.size(), 1);
            assertEquals(temp.get(0).intValue(), 8);
            RandomAccessFile blocks16  = new RandomAccessFile("samplein\\16Blocks.bin", "rw");
            temp = r.countRuns(blocks16);
            assertEquals(temp.size(), 2);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            RandomAccessFile blocks32  = new RandomAccessFile("samplein\\32Blocks.bin", "rw");
            temp = r.countRuns(blocks32);            
            assertEquals(temp.size(), 4);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            assertEquals(temp.get(2).intValue(), 8);
            assertEquals(temp.get(3).intValue(), 8);
            RandomAccessFile blocks64  = new RandomAccessFile("samplein\\64Blocks.bin", "rw");
            temp = r.countRuns(blocks64);            
            assertEquals(temp.size(), 8);
            assertEquals(temp.get(0).intValue(), 8);
            assertEquals(temp.get(1).intValue(), 8);
            assertEquals(temp.get(2).intValue(), 8);
            assertEquals(temp.get(3).intValue(), 8);
            assertEquals(temp.get(4).intValue(), 8);
            assertEquals(temp.get(5).intValue(), 8);
            assertEquals(temp.get(6).intValue(), 8);
            assertEquals(temp.get(7).intValue(), 8);
            RandomAccessFile blocks6 = new RandomAccessFile("samplein\\6Blocks.bin", "rw");
            temp = r.countRuns(blocks6);            
            assertNull(temp);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }
    
    /**
     * Test method for {@link sortFile#initialSort()}.
     */
    public void testCountRuns2() {
        sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
        ArrayList<Integer> previousRuns = new ArrayList<Integer>();
        ArrayList<Integer> nextRuns;
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 1);
        assertEquals(nextRuns.get(0).intValue(), 64);
        previousRuns.add(8);
        assertEquals(previousRuns.size(), 9);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 2);
        assertEquals(nextRuns.get(0).intValue(), 64);
        assertEquals(nextRuns.get(1).intValue(), 8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        previousRuns.add(8);
        nextRuns = r.countRuns(previousRuns);
        assertEquals(nextRuns.size(), 2);
        assertEquals(nextRuns.get(0).intValue(), 64);
        assertEquals(nextRuns.get(1).intValue(), 64);
        nextRuns = r.countRuns(nextRuns);
        assertEquals(nextRuns.size(), 1);
        assertEquals(nextRuns.get(0).intValue(), 128);
        int totalBlocks = 0;
        for (int i = 0; i < previousRuns.size(); i++) {
            totalBlocks += previousRuns.get(i).intValue();
        }
        assertEquals(totalBlocks, 128);
    }
    /**
     * Test method for {@link sortFile#initialSort()}.
     */
    public void testInitialSort() {
    	try {
            sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
            int blockRead = 0;
            r.runBlockCountList = r.countRuns(r.ioRaf);
            r.numberOfRuns = r.runBlockCountList.size();
            assertEquals(r.numberOfRuns, 1);
            while (blockRead < r.numberOfRuns) {
                //reads in the number of blocks expected for this run
                try {
                    for(int i = 0; i < 8; i++) {
                        r.mainMem.inputBuffer.inBuff.clear();
                        assertEquals(r.mainMem.inputBuffer.buff.length, 4096);
                        r.ioRaf.readFully(r.mainMem.inputBuffer.buff);
                        r.mainMem.inputBuffer.addBlock();
                        //TODO: add a block to the heap
                        r.mainMem.insert(r.mainMem.inputBuffer.popBlock());
                        System.out.println("root");
                        System.out.println(mainMemory.getKey(r.mainMem.buff.getLong(0)));
                        System.out.println(mainMemory.getKey(r.mainMem.buff.getLong(r.mainMem.size-9)));
                    }

                    //test the output
                    int j = 0;
                    long prevRecord = -1;
                    long nextRecord = -1;
                    ByteBuffer b = ByteBuffer.allocate(4096);
                    while(j < 8) {
                        b = r.mainMem.popMinBlock().inBuff;
                        nextRecord = b.getLong(0);
                        b.position(0);
                        int pos = 0;
                        if(j == 0) { prevRecord = nextRecord; }
                        while (b.hasRemaining()) {
                            assertTrue(mainMemory.compareTo(
                                    prevRecord, nextRecord) <= 0);
                            nextRecord = b.getLong();
                            pos+=8;
                            prevRecord = r.mainMem.parent(pos);
                            
                        }
                        assertEquals(b.position(), 4096);
                        j++;
                
                    } 
                }
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    fail("poor compilation");
                }
                //test the output to the runfile
                blockRead++; //add the next block
            }
        }
        catch(Exception e) {
            e.printStackTrace(System.out);
            fail("could not build");
        }
    }

    /**
     * Test method for {@link sortFile#compareTo(long, long)}.
     */
    public void testCompareTo() {
    	long a = 12;
     	long b = 20;
     	float w = 10.0f;
     	float e = 12.0f;
     	float q = -30.5f;
     	assertTrue(Float.compare(w, e) < 0);
     	assertTrue(Float.compare(w,q) > 0);
        assertEquals(Float.compare(q,q), 0);
     	
     	byte[] test = new byte[16];
     	test[0] = (byte)1; //20, 10 
        test[1] = (byte)2; //40, 30
        test[2] = (byte)3; //20
        test[3] = (byte)4; //40
        test[4] = (byte)5; //20, 10 
        test[5] = (byte)6; //40, 30
        test[6] = (byte)7; //20
        test[7] = (byte)8; //40
        test[8] = (byte)1; //20, 10 
        test[9] = (byte)2; //40, 30
        test[10] = (byte)3; //20
        test[11] = (byte)4; //40, 30
        test[12] = (byte)0; //20
        test[13] = (byte)0; //40
        test[14] = (byte)0; //20, 10 
        test[15] = (byte)0; //40, 30
        ByteBuffer buff = ByteBuffer.wrap(test);
     	assertTrue(sortFile.compareTo(buff.getLong(0), buff.getLong(8)) > 0);
     	test[12] = (byte)5; //20
        test[13] = (byte)6; //40
        test[14] = (byte)7; //20, 10 
        test[15] = (byte)8; //40, 30
        assertTrue(sortFile.compareTo(buff.getLong(0), buff.getLong(8)) == 0);
    }
    /**
     * Test method for the pushBlock function of the DataBuffer and the
     * getRecord function of the DataBuffer.
     */
    public void testDataBuffer() {
        sortFile r = new sortFile("a0.bin", "a1.bin", "a2.bin", "a3.bin");
        byte [] block = new byte[4096];
        block[0] = (byte)1;
        block[1] = (byte)2;
        block[2] = (byte)3;
        block[3] = (byte)4;
        block[4] = (byte)5;
        block[5] = (byte)6;
        block[6] = (byte)7;
        block[7] = (byte)8;
        block[8] = (byte)1;
        block[9] = (byte)2;
        block[10] = (byte)3;
        block[11] = (byte)4;
        block[12] = (byte)5;
        block[13] = (byte)6;
        block[14] = (byte)7;
        block[15] = (byte)8;
        ByteBuffer buff = ByteBuffer.wrap(block);
        r.mainMem.inputBuffer.pushBlock(block);
        byte[] fail = new byte[20];
        assertFalse(r.mainMem.inputBuffer.pushBlock(fail));
        assertTrue(sortFile.compareTo(r.mainMem.inputBuffer.inBuff.getLong(0),
        		buff.getLong(0)) == 0);
        long test = 0;
        test = r.mainMem.inputBuffer.getRecord(0);
        assertTrue(sortFile.compareTo(test, buff.getLong(8)) == 0);
    }

}
