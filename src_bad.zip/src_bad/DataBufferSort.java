import java.util.*;
import java.util.Map.Entry;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
//import java.io.PrintWriter;

/**
 * So from how I understand this, we have a 8 block memory that we put blocks into,
 * sort those 8 blocks when the memory is full,
 * then store those in another memory, then merge them sometime later?
 * 
 *
 */
public class DataBufferSort {
	//private array of blocks to act as memory
	/**
	 * this will store a block into the array of blocks
	 */
    private long lastExecTime;
    /**
     * Runs the heap sort of the buffer data
     * @return a long value representing the exec time
     */
    protected HashMap<Float,Long> hmIn;    
    protected HashMap<Float,Long> hmOut;
    protected HashMap<Float,Long> hmIn2;    
    protected HashMap<Float,Long> hmOut2;
    /**
     * constructor
     */
    public DataBufferSort() {
        hmIn = new HashMap<Float,Long>(1024, (float) 0.75);  
        hmOut = new HashMap<Float,Long>(1024, (float) 0.75);  
        lastExecTime = -1;
    }
   // private HashMap<long k, float v> map;// = new HashMap<>();
    long runHeapSort(){
        lastExecTime = -2;
        long stop = 0;
        long start = System.currentTimeMillis();
       // heapSort();
        stop = System.currentTimeMillis();
        lastExecTime = stop - start;
        return lastExecTime;
    };
    
    
    /**
	 * where we sort the private array of blocks in ascending order via the keys.
	 * it is then immediately stored into a new memory to be murged later?
	 */
	public void heapSort(RandomAccessFile rafIn, RandomAccessFile rafOut){
		
	}
	protected class Heap {
	    public void insertHashMap() {
	        
	    }
	    public void outputHashMap() {
	        
	    }
	}
}
