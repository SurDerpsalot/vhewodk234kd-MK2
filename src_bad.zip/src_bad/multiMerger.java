import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This class is used to multimerge files
 * @author Madelyn Newcomb m1newc
 * @version 11/7/2017
 *
 */
public class multiMerger {
    private RandomAccessFile rafIn;
    private RandomAccessFile rafOut;
    private ArrayList<Integer> runLengths;
    private int runCount;
    
    /**
     * default constructor
     */
    public multiMerger(RandomAccessFile inRAF, RandomAccessFile outRAF, 
            ArrayList<Integer> runLens) {
        rafIn = inRAF;
        rafOut = outRAF;
        runLengths = runLens;
        runCount = runLens.size();
    }
    
    
    
    /**
     * Determines the number of run blocks to result from merge-sorting once
     * @param numberOfRunBlocks is the number of runs input
     * @return the number of runs that will result from the input number of runs
     */
    protected int runCountFromMergeSort (int numberOfRunBlocks) {
        int numberOfRunBlocksOut = numberOfRunBlocks / 8;
        if (numberOfRunBlocks % 8 != 0) {
            numberOfRunBlocksOut++; 
        }
        return numberOfRunBlocksOut; 
    }
    /**
     * @param numberOfRunBlocks is the number of runs input
     * @param currentRunLengths is the the length of each run
     * returns the lengths of runs after the previous mergesort
     */
    protected ArrayList<Integer> runLengthsFromMergeSort(int numberOfRunBlocks, 
            ArrayList<Integer> currentRunLengths) {
        ArrayList<Integer> runLengthsOut = new ArrayList<Integer>();
        int len = runCountFromMergeSort(numberOfRunBlocks); 
        int i = 0;
        int lenCount = 0;
        while(i < len) {
            lenCount += currentRunLengths.get(i);
            if(i % 8 == 7) {
                runLengthsOut.add(lenCount);
                lenCount = 0;
            }
            i++;
        }
        if (lenCount != 0) {
            runLengthsOut.add(lenCount);
        }
        if (runLengthsOut.size() != len) {
            System.err.println("This logic is wrong");
        }
        return runLengthsOut; 
     }
    
    /**
         * when the number of runs that need to be merged is at 
         * least 8, we should compare one block of data at a time 
         * from 8 different runs. This is the largest amount of 
         * data we can pull from the file at a time, and pulling 
         * smaller increments will be less efficient than running 
         * the merge sort again on a another set of larger runs.
      */
    public void multiMerge(){
//            ArrayList<HashMap<Float, Long>> hmList = null;    
        ArrayList<Integer> currPosList = null;
        ArrayList<List<Map.Entry<Float,Long>>> pairList =
                new ArrayList<List<Map.Entry<Float,Long>>>();
        long value;
        float key;
        try {
            rafIn.seek((long)0);
            int blocksInHeap = 0;
            int blocksProcessed = 0; //the number of blocks already run through the sort
            ByteBuffer inBuffer = ByteBuffer.allocate(0x1000);
            ByteBuffer outBuffer = ByteBuffer.allocate(0x1000);
            ByteBuffer heap1 = ByteBuffer.allocate(0x8000);
            while(runCount > 0) {
                if(runCount < 8 ) {
                    //optimize the function to utilize the entire space
                    runCount = 0 ;
                    blocksProcessed = runCount;
                }
                else {
                    //reading from the next 8 blocks
                    for (int j = 0; j < 8; j++) { //adjust for block offset
                        rafIn.seek(j*0x1000 + blocksProcessed*0x8000); //move to next run                       
                        rafIn.read(inBuffer.array(), 0, 0x1000);
                        inBuffer.position(0);
                        inBuffer.get(heap1.array(), j*0x1000, 0x1000);                        
                    }
                    runCount -= 8;
                    blocksProcessed += 8;
                }
                //run mergesort on heap
                //TODO: parse bytebuffer values
                
            }
            //TODO: run the multi-merge sort again if not done.    
        }
        catch (IOException e) {
            System.err.println("Writing error: " + e);
        }

    }
    

}
