import java.io.RandomAccessFile;
import java.nio.ByteBuffer;

//import java.io.PrintWriter;

public class DataBuffer {
	//private array of blocks to act as memory
//    private long lastExecTime;   
    int blockSize;
    int blockFillSize;
    protected byte[] buff;   
    protected ByteBuffer inBuff;
    /**
     * constructor
     */
    public DataBuffer(int size) {
        blockSize = size; //size in bytes of a block, and the buffer
        blockFillSize = 0;
    	buff = new byte[size];
        inBuff = ByteBuffer.wrap(buff);
  //      lastExecTime = -1;
    }
    /**
     * increments the filled space based by a block
     */
    public void addBlock() {
        blockFillSize += blockSize;        
    }
    /**
     * pushes a block of data into this buffer space
     * @param block the input data
     * @return true if the block was pushed correctly
     */
    public boolean pushBlock(byte[] block) {
        if(block.length != blockSize) {
            return false;
        }
        blockFillSize += blockSize;
        inBuff.clear();
        inBuff.put(block);
        return true;
    }
    /**
     * pops an entire block of data
     * @return
     */
    public byte[] popBlock() {
        blockFillSize -= blockSize;
        return inBuff.array();
    }
    /**
     * given a position in the buffer, returns a record
     * @param record
     * @return
     */
    public long getRecord(int record) {
        return inBuff.asLongBuffer().get(record);
    }
    /**
     * Runs the heap sort of the buffer data
     * @return a long value representing the exec time
     
    long runHeapSort(){
        lastExecTime = -2;
        long stop = 0;
        long start = System.currentTimeMillis();
       // heapSort();
        stop = System.currentTimeMillis();
        lastExecTime = stop - start;
        return lastExecTime;
    };
	*/
}
