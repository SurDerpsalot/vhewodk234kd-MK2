import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
//import java.io.PrintWriter;
import java.util.Scanner;
import static java.lang.Math.toIntExact;


public class Parser {
    int BLOCK_BYTES = 4096;
    int RECORD_BYTES = 8;
	private String inFile;
	private Heap theHeap;
	private String outFile;
	private String runningFile1;
	private RandomAccessFile raf; 
	private DataBufferSort dbs;
	public Parser(String inputFile, String outputFile){
	    dbs = new DataBufferSort();
	    inFile = inputFile;
		outFile = outputFile;
		try {
		    raf = new RandomAccessFile(inFile, "rw");
		}
        catch (FileNotFoundException e) {
            System.err.println("Could not file file:" );
        } 
	}
	/**
	 * This function will read in the first block and then parse it out and
	 * store the values and keys to be heapSorted. To be 100% honest, I am
	 * very confused about how most everything in this project is working.
	 */
	public void parse() { 
		try {
			long offset = 0;
			//Get the position of the first record (should be 0):
			offset = raf.getFilePointer();
			//Grab first line (first complete record):
            if (raf.length() % (8 * BLOCK_BYTES) != 0 ) {
                System.out.println("Error: bad file length");
                return;
            }
            long numberOfBlocks = raf.length() / (BLOCK_BYTES);
            for(long b = 0; b < numberOfBlocks; b++) {
                offset = parseAndDump(b, offset);
            };
            System.out.println("The number of blocks is: " + (raf.length()/BLOCK_BYTES));
			
		} 
		catch (IOException e) {
			System.err.println("Writing error: " + e);
		}
	}
	/**
	 * 
	 */
	private long parseAndDump(long blockNumber, long fileOffset) {
	    try {
	        raf.seek(fileOffset);
            //read the block entirely 
            raf.readFully(dbs.hmIn);
            //Tell the world:
            System.out.println("The block is: " 
                    + (blockNumber));
            return raf.getFilePointer();        
	    }
	    catch (IOException e) {
            System.err.println("Writing error: " + e);
	    }
	    return -1;
	}
} //end of ParseData class

