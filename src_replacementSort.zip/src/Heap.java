import java.nio.ByteBuffer;
//import java.nio.LongBuffer;
public class Heap {
	public int darkzone;
	public int size;
	public byte[] list;
	public ByteBuffer buff = ByteBuffer.wrap(list);
	
	//I don't know if this would help and make things easier to read
	//public LongBuffer longBuff = LongBuffer.wrap(buff.asLongBuffer().array());
	public Heap() {
		list = new byte[32768];
		size = 0;
		darkzone = 0;
        buff.clear();
    }
    public void insert(byte[] items) {
    	buff.put(items);
    	size = size + 512;
    	buildHeap();
    }
    public void reset(){
    	size = buff.asLongBuffer().array().length;
    	darkzone = 0;
    	buildHeap();
    }
    public void buildHeap() {
        for (int i = size / 2; i >= 0; i--) {
            minHeapify(i);
        }
	}
    public static int compareTo(long a, long b){
    	float aF = (a<<32)>>32;
    	float bF = (b<<32)>>32;
    	if(aF-bF == 0)
    	{
    		int aI = (int) (a>>32);
    		int bI = (int) (b>>32);
    		if(aI-bI == 0)
    		{
    			return 0;
    		}
    		else
    		{
    			return aI-bI;
    		}
    	}
    	else
    	{
    		return (int) (aF-bF);
    	}
    }
    private void minHeapify(int i) {
        int left = left(i);
        int right = right(i);
        int smallest = -1;
        // find the smallest key between current node and its children.
        // left < i
        if (left <= size - 1 && 
        		compareTo(buff.asLongBuffer().get(left), buff.asLongBuffer().get(i)) <= 0) {
            smallest = left;
        } else {
            smallest = i;
        }
        //right < smallest
        if (right <= size - 1 &&
        		compareTo(buff.asLongBuffer().get(right), buff.asLongBuffer().get(smallest)) <= 0) {
            smallest = right;
        }
        // if the smallest key is not the current key then bubble-down it.
        if (smallest != i) {
            swap(i, smallest);
            minHeapify(smallest);
        }
    }
    public void darkZoneSwappage(){
    	swap(0,size);
    	size = size - 1;
    	darkzone = darkzone + 1;
    	buildHeap();
    }
    public boolean isEmpty() {
        return buff.asLongBuffer().hasRemaining();
    }
    public int getSize() {
    	return size;
    }
    public int getSizeBlocks() {
    	return size/512;
    }
    private int right(int i) {
        return 2 * i + 2;
    }
    private int left(int i) {
        return 2 * i + 1;
    }
	private void swap(int i, int parent) {
        long temp = buff.asLongBuffer().get(parent);
        buff.asLongBuffer().put(parent, buff.asLongBuffer().get(i));
        buff.asLongBuffer().put(i, temp);
    }
}
