import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
/**
 * This is the class used for replacement selection
 * @author bfin96, m1newc
 *
 */
public class sortFile {
	int BLOCK_BYTES = 4096;
	int RECORD_BYTES = 8;
	int numberOfRuns; //the number of runs to export in the next external sort
	protected ArrayList<Integer> runBlockCountList; //lengths of each run saved in blocks
	protected ArrayList<Integer> positionsList; //positions to read in the heap
	//private ArrayList<Integer> runLength;
    private mainMemory mainMem;
	private RandomAccessFile ioRaf; //the file to sort
    private RandomAccessFile runRaf;
    private RandomAccessFile run2Raf;
    private RandomAccessFile statRaf;
	private DataBuffer inputBuffer;
    private DataBuffer outputBuffer;
	//since the runs can end with an incomplete block, 
	//the length is in records not in blocks
	/**
     * The constructor for the ReplacementSort
     * @param inputFile the file to read bytes from
     * @param runFile the file where the first sorting run of the file goes
   	 * @param run2File the second temporary file used to sort runs
	 * @param statFile the statistics file
	 */
	public sortFile(String inputFile, String runFile, String run2File, String statFile) { 
		inputBuffer = new DataBuffer(BLOCK_BYTES);
        outputBuffer = new DataBuffer(BLOCK_BYTES);
        //resetPositionsList(8);   //<-- This was giving an error
		mainMem = new mainMemory(positionsList);
		//runLength = new ArrayList<Integer>();
		try {
		    ioRaf = new RandomAccessFile(inputFile, "rw");
            runRaf = new RandomAccessFile(runFile, "rw");
            run2Raf = new RandomAccessFile(run2File, "rw");
            statRaf = new RandomAccessFile(statFile, "rw");
            clearRAF(runRaf);
            clearRAF(run2Raf);            
		}
		catch (FileNotFoundException e) {
			System.err.println("Could not find file.");
		} 
	}
	/**
	 * resets the positionsList to point to only the first element of each block
	 * @param positions is the number of blocks to reference
	 */
	private void resetPositionsList(int positions){
	    positionsList.clear();
	    for(int i = 0; i < positions; i++) {
	       positionsList.add(0); 
	    }
	    mainMem.positions = positionsList;
	}
	
	/**
	 * return an array that is the length of the expected number of 
	 * runs in order to sort this file. The elements of the output array
	 * are the number of blocks that will be processed in each run.
	 * @param raf is the file to check
	 * @return a list of integers
	 */
	protected ArrayList<Integer> countRuns(RandomAccessFile raf) {
	    ArrayList<Integer> temp = new ArrayList<Integer>();
	    try {
            if(raf.length() % BLOCK_BYTES != 0) {
                return null;
            }
            int numberOfBlocksInRAF = (int) (raf.length() / BLOCK_BYTES);
            //N is the number of runs that will be created given the 
            //number of blocks in the RAF
            int N = numberOfBlocksInRAF + 4 / 8; 
            while(N > 8) {
                temp.add(8);
                N--;
            }
            temp.add(N);
            return temp;
        } 
	    catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
	}
    /**
     * for all subsequent runs, you can find their next sizes using the 
     * previous one
     * @param givenRuns an array of the lengths of the previous runs
     * @return the expected lengths of your next set of runs in blocks
     */
	protected ArrayList<Integer> countRuns(ArrayList<Integer> givenRuns) {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        int numberOfRunsGiven = givenRuns.size();
        //N is the number of runs that will be created given the 
        //number of blocks in the RAF
        int i = 0;
        int j = -1;
        while(i < numberOfRunsGiven) {
            if(i % 8 == 0) {
                j++;
                temp.add(givenRuns.get(i));
            }
            else {
                temp.set(j,temp.get(j) + givenRuns.get(i));                    
            }
            i++;
        }
        return temp;
    } 
    /**
     * @param record is the 16-byte number with a value-key pair
     * @return float key is the LSB 4-bytes from the long
     */
    public static float getKey(long record) {
    	 byte[] test = new byte[8];
  	   ByteBuffer buff = ByteBuffer.wrap(test);
  	   buff.putLong(record);
         return buff.getFloat(4);
    }
    /**
     * @param record is the 16-byte number with a value-key pair
     * @return unsigned int value is the MSB 4-bytes from the long
     */
    public static long getValue(long record) {
        return (long)(record >>> 32); //logical shift right
    }
	/**
	 * clears a specified RandomAccessFile
	 * @param raf the file to clear
	 */
	void clearRAF(RandomAccessFile raf) {
	    try {
	        raf.setLength(0);
	    }
	    catch (Exception e) {
	        System.err.println("Could not clear file.");    
	    }
	}
	/**
	 * This is the first run which will quicksort blocks of the inputFile
	 * @return true if executed successfully
	 */
	public boolean initialRun() {
	    int blockRead = 0;
	    while (blockRead < numberOfRuns) {
	        //reads in the number of blocks expected for this run
	        for(int i = 0; i < 8; i++) {
	            try {
                    ioRaf.readFully(inputBuffer.buff);
                  //  System.out.println("butts");
                    inputBuffer.addBlock();
                    //System.out.println("butts");
                    //TODO: add a block to the heap
                    mainMem.insert(inputBuffer.popBlock());
                    //System.out.println("butts");
                    System.out.println("root");
                    System.out.println(getKey(mainMem.buff.getLong(0)));
                    System.out.println("butt");
                    System.out.println(getKey(mainMem.buff.getLong(mainMem.size-9)));
                } 
	            catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    return false;
                }
	        }
	       
	        //process the run
	        mainMem.quickSort();
	      //reads in the number of blocks expected for this run
            for(int i = 0; i < 8; i++) {
                try {
                	System.out.print("butts");
                    mainMem.buff.get(outputBuffer.buff, i*BLOCK_BYTES, BLOCK_BYTES);
                    outputBuffer.addBlock();
                    //TODO: add a block to the heap
                    runRaf.write(outputBuffer.popBlock());
                } 
                catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    return false;
                }
            }
	        blockRead++; //add the next block
	    }
	    return true;
	}
	/////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    /**
     * This is the main algorithm for running this entire system of sorting
     */
	public long sort() {
        long stop = 0;
        long lastExecTime = -2;
        long start = System.currentTimeMillis();
        runBlockCountList = countRuns(ioRaf);
        numberOfRuns = runBlockCountList.size();
	    //import all the data from the input file
	    //it will organize the blocks of data into N runs, 
	    //where N is the number of 8*blockbytesize chunks in the input file.
        initialRun();
        //everything is now in the runFile.  
        //until the number of merges satisfies the requirement to sort the 
        //entire file, it will pass data back an forth between the two runfiles
        boolean inRun2Final = (numberOfRuns % 2 == 0);
        int i = 0;
        while(numberOfRuns > 1) {
            resetPositionsList(8);
            while(i < numberOfRuns) {
                //TODO: initialize run start positions. Get rid of global numberOfRuns
                //ToDo: mergesort while exporting to the oppositerunfile
                if(i % 2 == 0) {
                    //positions = mergesort(runFile, run2File);
                }
                else {
                    //positions = mergesort(run2File, runFile);
                }
                i++;
                
            }
            //next number of runs to be expected. 
            //When there is only one run, it is the final one
            runBlockCountList = countRuns(runBlockCountList);
            numberOfRuns = runBlockCountList.size(); 
        }
        //post-processing
        if(inRun2Final) {
            saveInTheInputFile(ioRaf, run2Raf);
        }
        else {
            saveInTheInputFile(ioRaf, runRaf);
        }
        stop = System.currentTimeMillis();
        lastExecTime = stop - start;
        return lastExecTime;
    }
	/**
	 * saving an entry in the statistics file
	 * @param lastExecTime this is the execution time
	 * @param statName the name of the statistics file
	 * @return true if successful
	 */
	protected boolean saveInTheStatisticsFile(long execTime, 
	        String statName) {
	    try {
	        statRaf.writeBytes(String.format("%l %s\n", execTime, statName));
            return true;
        }
        catch(Exception e) {
            System.err.println("Printing Error: " + e.toString());
        }
        return false;
        
    }
    /**
     * saves in the user-specified file, the result, and 
     * prints to the system every block's first element
     * @param outRaf where to save
     * @param runRaf what to save
     * @return true if successfully completed
     */
    protected boolean saveInTheInputFile(RandomAccessFile outRaf, 
        RandomAccessFile rRaf) {
        try {
            outRaf.setLength(0);
            long recordLong;
            long recordValue;
            float recordKey;
            int numberOfEntries = (int)(rRaf.length() / 4096);
            for(int i = 0; i < numberOfEntries; i++) {
                //TODO: see if I need to update the file pointer, 
                //or if it does that automatically
                rRaf.readFully(inputBuffer.buff, i*BLOCK_BYTES, BLOCK_BYTES);
                inputBuffer.addBlock();
                recordLong = inputBuffer.getRecord(0);
                recordKey = getKey(recordLong);
                recordValue = getValue(recordLong);
                outRaf.write(inputBuffer.popBlock());
                if(i % 5 != 4) {
                    System.out.format("%l %f ", recordValue, recordKey);
                }
                else {
                    System.out.format("%l %f\n", recordValue, recordKey);
                }
            }
            return true;
        }
        catch(Exception e) {
            System.err.println("Printing Error: " + e.toString());
        }
        return false;
        
    }
/*
   protected void mainMemGetSmallestToOutputBuffer() {
        int i = 0;
        while (i < 512) {
            mainMem.mainMemSmallestValue();
            if(mainMem.getEmptyBlock() > 0) { //there is a block that can be filled in the mainMemory
                if (there is soemthing to fill it with) {
                    inputBuffer.inBuff.put(next block in the position that is empty);
                }
            }
            i++;
        }

   }*/
	/////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
	
/*	*//**
	 * This function check the file for proper styling input
	 * and then fills up the heap. It then will do a run per iteration
	 * of the while loop until there is no more input.
	 *//*
	public void run() {
		try {
            if (ioRaf.length() % (8 * BLOCK_BYTES) != 0 ) {
                System.out.println("Error: bad file length");
                return;
            }
            //long numberOfBlocks = raf.length() / (BLOCK_BYTES);
            fillTheHeap();
            ioRaf.readFully(inputBuffer.buff);
            while(theHeap.getSize() < theHeap.list.length) {
            	outTheHeap();
            	resetTheHeap();
            }
            System.out.println("The number of blocks is: " + (ioRaf.length()/BLOCK_BYTES));
			
		} 
		catch (IOException e) {
			System.err.println("Writing error: " + e);
		}
	}
	
	*//**
	 * This function fills the heap with its full 8 blocks. 
	 * A block is put in the input buffer, then filled into the min-heap
	 *//*
	public void fillTheHeap()
	{
		while(theHeap.getSize() < 4096) {
			try {
			    ioRaf.readFully(dbs.hmIn);
				theHeap.insert(dbs.inBuff.array());
				dbs.inBuff.clear();
			}
			catch(IOException e) {
		        System.err.println("Writing error: " + e);
			}
		}
	}
	
	*//**
	 * This function runs the replacement sort algorithm and writes
	 * to the output buffer. When the output buffer is full it outputs
	 * to the run file
	 *//*
	public void outTheHeap(RandomAccessFile outRaf){
		outputBuffer.inBuff.clear();
		outputBuffer.inBuff.putLong(mainMem.buff.getLong(0));
		mainMem.buff.putLong(inputBuffer.inBuff.getLong());
		mainMem.buildHeap();
		int i = 0;
		int length = 0;
		while(mainMem.darkzone < 4096)
		{
			//if the smallest element in the heap is smaller than the largest 
			//value in the output buffer
			if(compareTo(mainMem.buff.getLong(0), dbs.outBuff.getLong(i)) < 0)
			{
				//rebuilds the tree *hopefully* like it do in replacement sort
			    mainMem.darkZoneSwappage();
			}
			else
			{
				outputBuffer.inBuff.putLong(mainMem.buff.getLong(0));
				i = i+1;
				if(!inputBuffer.inBuff.hasRemaining())
				{
				    inputBuffer..inBuff.clear();
					try {
						ioRaf.readFully(inputBuffer.buff);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				mainMem.buff.putLong(0, inputBuffer.inBuff.getLong());
				mainMem.buildHeap();
				length = length + 1;
				if(!outputBuffer.inBuff.hasRemaining())
				{
					try {
						outRaf.write(outputBuffer.buff);
					} catch (IOException e) {
						e.printStackTrace();
					}
					outputBuffer.inBuff.clear();
				}
			}
		}
		//run is now over. put out the end of run item (float of -1) and
		//add the length of the run to the array.
		runLength.add(length);
		outputBuffer.inBuff.putLong(-1);
		try {
			outRaf.write(outputBuffer.buff);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
*/	/**
	 * This function resets the heap after the darkzone has claimed the 
	 * entire heap, ending a run.
	 */
	public void resetTheHeap() {
		mainMem.reset();
	}
	
	
	/**
	 * This function compares two key values against each other and returns
	 * a positive if A > B, negative if A < B, and 0 if A = B.
	 * It also compares integers if the keys are the same.
	 * @param a the first record to be compared
	 * @param b the second record to be compared
	 * @return the positive, negative, or 0 result of their subtraction.
	 */
	public static int compareTo(long a, long b) {
	    	float aF = getKey(a);
	    	float bF = getKey(b);
	    	long aI = getValue(a);
	    	long bI = getValue(b);
	    	return (Float.compare(aF, bF) != 0 ) ? Float.compare(aF, bF) : Long.compare(aI, bI);
	    	
	    }
}
