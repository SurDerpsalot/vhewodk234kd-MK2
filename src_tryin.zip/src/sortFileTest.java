import java.nio.ByteBuffer;
import java.nio.LongBuffer;

/**
 * @author maden
 * unit test for the replacement method
 */
public class sortFileTest extends student.TestCase {

    /**
     * Test method for {@link sortFile#sortFile(
     *  java.lang.String, java.lang.String)}.
     */
    public void testsortFile() {
        try {
            sortFile r = new sortFile("a0.bin", "a1.txt", "a1.bin", "a2.txt");
        }
        catch(Exception e) {
            fail("could not build");
        }
    }

    /**
     * Test method for {@link sortFile#run()}.
     */
    public void testRun() {
    	try {
            sortFile r = new sortFile("a0.bin", "a1.txt", "a1.bin", "a2.txt");
            r.sort();
        }
        catch(Exception e) {
            fail("could not build");
        }
    }

    /**
     * Test method for {@link sortFile#fillTheHeap()}.
     */
    public void testFillTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#outTheHeap()}.
     */
    public void testOutTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#resetTheHeap()}.
     */
    public void testResetTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#compareTo(long, long)}.
     */
    public void testCompareTo() {
    	long a = 12;
     	long b = 20;
     	float w = 10.0f;
     	float e = 12.0f;
     	float q = -30.5f;
     	assertTrue(Float.compare(w, e) < 0);
     	assertTrue(Float.compare(w,q) > 0);
     	
     	
     	byte[] test = new byte[16];
     	test[0] = (byte)1; //20, 10 
        test[1] = (byte)2; //40, 30
        test[2] = (byte)3; //20
        test[3] = (byte)4; //40
        test[4] = (byte)5; //20, 10 
        test[5] = (byte)6; //40, 30
        test[6] = (byte)7; //20
        test[7] = (byte)8; //40
        test[8] = (byte)1; //20, 10 
        test[9] = (byte)2; //40, 30
        test[10] = (byte)3; //20
        test[11] = (byte)4; //40, 30
        test[12] = (byte)0; //20
        test[13] = (byte)0; //40
        test[14] = (byte)0; //20, 10 
        test[15] = (byte)0; //40, 30
        ByteBuffer buff = ByteBuffer.wrap(test);
     	assertTrue(sortFile.compareTo(buff.getLong(0), buff.getLong(8)) > 0);
     	test[12] = (byte)5; //20
        test[13] = (byte)6; //40
        test[14] = (byte)7; //20, 10 
        test[15] = (byte)8; //40, 30
        assertTrue(sortFile.compareTo(buff.getLong(0), buff.getLong(8)) == 0);
        
     	// assertTrue(sortFile.compareTo(buff.getLong(0), buff.getLong(8)) == 0);
    }

}
