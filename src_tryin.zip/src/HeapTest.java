/**
 * @author maden
 *
 */
public class HeapTest extends student.TestCase {

    /**
     * Test method for {@link Heap#Heap()}.
     */
    public void testHeap() {
     /*   Heap test = new Heap();
        assertEquals(test.getSize(), 0);
        assertEquals(test.list.length, 32768);
        assertEquals(test.darkzone, 0);
        assertEquals(test.buff.capacity(), 32768);
        assertTrue(test.isEmpty());*/
    }

    /**
     * Test method for {@link Heap#compareTo(long, long)}.
     */
    public void testCompareTo() {
        mainMemory test = new mainMemory();
        assertTrue(test.compareTo((long)12, 0x0) > 0);
        assertTrue(test.compareTo(0x0, (long)12) < 0);
        assertTrue(test.compareTo(0xFFFFF, 0x0) > 0);
        assertTrue(test.compareTo(0x0, 0xFFFFF) < 0);
        assertEquals(test.compareTo(3, 3), 0);
        assertEquals(test.compareTo(0xFFFFF, 0xFFFFF), 0);
    }

    /**
     * Test method for {@link Heap#isEmpty()}.
     */
    public void testSwap() {
        mainMemory test = new mainMemory();
        test.list[0] = (byte)0; //20, 10   index 0
        test.list[1] = (byte)0; //40, 30
        test.list[2] = (byte)0; //20
        test.list[3] = (byte)40; //40
        test.list[4] = (byte)0; //20, 10 
        test.list[5] = (byte)0; //40, 30
        test.list[6] = (byte)0; //20
        test.list[7] = (byte)40; //40
        test.list[8] = (byte)0; //20, 10     index 1
        test.list[9] = (byte)0; //40, 30
        test.list[10] = (byte)0; //20
        test.list[11] = (byte)0; //40, 30
        test.list[12] = (byte)0; //20
        test.list[13] = (byte)0; //40
        test.list[14] = (byte)0; //20, 10 
        test.list[15] = (byte)30; //40, 30
        test.list[16] = (byte)0; //20, 10    index 2
        test.list[17] = (byte)0; //40, 30
        test.list[18] = (byte)0; //20
        test.list[19] = (byte)0; //40
        test.list[20] = (byte)0; //20, 10 
        test.list[21] = (byte)0; //40, 30
        test.list[22] = (byte)0; //20
        test.list[23] = (byte)20; //40
        test.list[24] = (byte)0; //20, 10   index 3 
        test.list[25] = (byte)0; //40, 30
        test.list[26] = (byte)0; //20
        test.list[27] = (byte)20; //40, 30
        test.list[28] = (byte)0; //20
        test.list[29] = (byte)0; //40
        test.list[30] = (byte)0; //20, 10 
        test.list[31] = (byte)10; //40, 30
        test.size = 4;
        assertFalse(test.swap(2,3));
        assertFalse(test.swap(2,-2));
        assertFalse(test.swap(8,0));
        assertEquals(test.list[3], 40);
        assertEquals(test.list[7], 40);
        assertTrue(test.swap(3,0));
        assertEquals(test.list[3], 20);
        assertEquals(test.list[7], 10);
        assertEquals(test.list[27], 40);
        assertEquals(test.list[31], 40);
        assertTrue(test.swap(3,1));
        assertEquals(test.list[11], 40);
        assertEquals(test.list[15], 40);
        assertEquals(test.list[27], 0);
        assertEquals(test.list[31], 30);
        assertTrue(test.swap(2,0));
        assertEquals(test.list[3], 0);
        assertEquals(test.list[7], 20);
        assertEquals(test.list[19], 20);
        assertEquals(test.list[23], 10);

    }
}/*
    *//**
     * Test method for {@link Heap#insert(byte[])}.
     *//*
    public void testInsert() {
       byte [] badinput = { 10, 9, 9, 7, 6, 5, 4, 3, 2, 1, 0 }; 
       byte [] badinput2 = null;
       byte [] badinput3 = { 1 };
       
       Heap test = new Heap();
       assertFalse(test.insert(badinput));
       assertFalse(test.insert(badinput2));
       test.size = 0xF000;
       assertFalse(test.insert(badinput3));
       test.reset();
       byte [] goodinput = new byte[4096*2];
       for(int i = 0; i < 4096*2; i++) {
           goodinput[i] = (byte)(i % 16);
       }
       assertTrue(test.insert(goodinput));
       assertEquals(test.getSizeBlocks(), 2);
       
    }


    *//**
     * Test method for {@link Heap#reset()}.
     *//*
    public void testReset() {
        Heap test = new Heap();
        assertTrue(test.isEmpty());
        for(int i = 0; i < 32; i++) {
           test.buff.asLongBuffer().put(i, i); 
           System.out.println("here");
           System.out.println(i*8+7);
           test.buff.asLongBuffer().position(i);
           System.out.println(test.buff.asLongBuffer().get());
           System.out.println(i);
           assertEquals(test.list[i*8 + 7], i);
           assertEquals(test.buff.asLongBuffer().get(i), i);
        }
        //TODO: make this commented assertion work:
//      assertFalse(test.isEmpty());
        test.reset();
        assertTrue(test.isEmpty());
    }
    *//**
     * Test method for {@link Heap#buildHeap()}.
     *//*
    public void testBuildHeap() {
        Heap test = new Heap();
        //build presorted
        for(int i = 0; i < 32; i++) {
           test.buff.asLongBuffer().put(i, i); 
           assertEquals(test.list[i*8 + 7], i);
        }
        test.buildHeap();
        for(int i = 0; i < 32; i++) {
            assertEquals(test.list[i*8 + 7], i);
        }
        //build slightly out of order
        test.reset();
        for(int i = 0; i < 32; i++) {
           int j = (i % 2 == 0) ? i + 1 : i - 1;
            test.buff.asLongBuffer().put(i, j); 
           assertEquals(test.list[i*8 + 7], j);
        }
        test.buildHeap();
        test.size = 32;
        for(int i = 0; i < 32; i++) {
            int parent = test.parent(i);
            if (i != 0) {
                //true if the child is bigger than the parent
                assertTrue(Heap.compareTo(test.buff.asLongBuffer().get(i),
                    test.buff.asLongBuffer().get(parent)) > 0);
            }
        }
        //build backwards
        test.reset();
        for(int i = 0; i < 32; i++) {
            test.buff.asLongBuffer().put(i, 31 - i); 
            assertEquals(test.list[i*8 + 7], 31 - i);
         }
        test.buildHeap();
        for(int i = 0; i < 32; i++) {
            assertEquals(test.list[i*8 + 7], i);
        }
        //build out of order
        test.reset();
        for(int i = 0; i < 32; i++) {
            test.buff.asLongBuffer().put(i, 31 - i + (i % 4)); 
            assertEquals(test.list[i*8 + 7], 31 - i + (i % 4));
         }
        test.buildHeap();
        for(int i = 0; i < 32; i++) {
            assertEquals(test.list[i*8 + 7], i + (i % 4)); //idk about thisone
        }
    }


    *//**
     * Test method for {@link Heap#darkZoneSwappage()}.
     *//*
    public void testDarkZoneSwappage() {
        Heap test = new Heap();
        //build presorted
        for(int i = 0; i < 32; i++) {
           test.buff.asLongBuffer().put(i, i); 
           assertEquals(test.list[i*8 + 7], i);
        }
        test.size = 32;
        assertEquals(test.buff.asLongBuffer().get(0), 0);
        assertEquals(test.buff.asLongBuffer().get(31), 31);
        
        test.darkZoneSwappage();
        assertEquals(test.buff.asLongBuffer().get(0), 31);
        assertEquals(test.buff.asLongBuffer().get(31), 0);
        assertEquals(test.getSize(), 31);

        
     }


    *//**
     * Test method for {@link Heap#getSizeBlocks()}.
     *//*
    public void testGetSizeBlocks() {
        Heap test = new Heap();
        //build presorted
        test.size = 1024;
        assertEquals(test.getSizeBlocks(), 2);
    }
    public void testParent() {
        Heap test = new Heap();
        assertEquals(test.parent(0), -1);
        assertEquals(test.parent(test.getSize()), -1);
        for(int i = 0; i < 32; i++) {
            test.buff.asLongBuffer().put(i, i); 
            assertEquals(test.list[i*8 + 7], i);
        }
        test.size = 32*8;
        assertEquals(test.parent(test.getSize()), -1);
        assertEquals(test.parent(3), 1);
        assertEquals(test.parent(4), 1);
        assertEquals(test.parent(11), 5);
        assertEquals(test.parent(13), 6);
        assertEquals(test.parent(14), 6);

    }

}
*/