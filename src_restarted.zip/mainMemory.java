import java.nio.ByteBuffer;
import java.util.ArrayList;
//import java.nio.LongBuffer;
/**
 * class for our heap structure
 * @author bfin96, maden
 *
 */
public class mainMemory {
	public int darkzone; //number of completely sorted values
	public int lightzone; //number of unsorted positions
	protected int records; //number of records in the heap
	protected int size; //number of bytes used in the heap (records*8)
	public byte[] list; //heap storage
	public ByteBuffer buff; //byte buffer wrapped to the list
    ArrayList<Integer> positions; //list of reading positions in the heap
//    ArrayList<ArrayList<Integer>> smallestValues; //use insertion sort to save the comparisons in order to make the search faster
	//I don't know if this would help and make things easier to read
	//public LongBuffer longBuff = LongBuffer.wrap(buff.asLongBuffer().array());
	/**
	 * constructor
	 */
	public mainMemory(ArrayList<Integer> pos) {
		list = new byte[32768];
		size = 0;
		records = 0;
		darkzone = 0;
		lightzone = 32767;
		buff = ByteBuffer.wrap(list);
		positions = pos;
    }
	/**
	 * insert an array of bytes into the heap
	 * @param items the array of bytes
	 */
    public boolean insert(byte[] items) {
        if(items == null) {
            return false;
        }
    	if(items.length % 4096 != 0) {
    	    return false; //not a block
    	}
    	if(size + items.length > lightzone + 1) {
    	    return false; //out of bounds
    	}
    	
        buff.put(items);
        records = records + items.length / 8;
    	size = size + items.length; //TODO:why 512?
    	buildHeap();
    	return true;
    }
    /**
     * quickly sorts the main memory
     */
    public void quickSort() {
        
    }
    /**
     * resets the size of the heap, as well as the sorted region.
     * It heapifies.
     */
    public void reset(){
        long [] temp = new long[1024];
        buff.asLongBuffer().get(temp);
    	size = 0;
    	records = 0;
    	darkzone = 0;
        lightzone = 32767;
    	buildHeap();
    }
    /**
     * build a minHeap
     */
    public void buildHeap() {
        for(int i = records / 2; i >= 0; i--) {
            minHeapify(i);
        }
	}
    /**
     * overloads the compareTo function to include long number comparisons
     * @param a first long number for comparison
     * @param b second long number for comparison
     * @return 0 if they are the same. A positive number if
     * a follows b, and a negative number if b precedes a.
     */
    public static int compareTo(long a, long b) {
    	float aF = (a<<32)>>32;
    	float bF = (b<<32)>>32;
    	if(aF-bF == 0)
    	{
    		int aI = (int) (a>>32);
    		int bI = (int) (b>>32);
    		if(aI-bI == 0)
    		{
    			return 0;
    		}
    		else
    		{
    			return aI-bI;
    		}
    	}
    	else
    	{
    		return (int) (aF-bF);
    	}
    }
    /**
     * build a level for a minHeap
     * @param i the current array pos in the heap
     */
    private void minHeapify(int i) {
        int left = left(i);
        int right = right(i);
        int smallest = -1;
        // find the smallest key between current node and its children.
        // left < i
        if (left <= end() && 
        		compareTo(buff.asLongBuffer().get(left), buff.asLongBuffer().get(i)) <= 0) {
            smallest = left;
        } else {
            smallest = i;
        }
        //right < smallest
        if (right <= end() &&
        		compareTo(buff.asLongBuffer().get(right), buff.asLongBuffer().get(smallest)) <= 0) {
            smallest = right;
        }
        // if the smallest key is not the current key then bubble-down it.
        if (smallest != i) {
            swap(i, smallest);
            minHeapify(smallest);
        }
    }
    /**
     * move a value into the end of the array and pretend it isn't there.
     */
    public void darkZoneSwappage(){
    	swap(end(), 0); //TODO: check that this is correct. I changed this
    	// from size to end() because we would lose a long byte otherwise
    	records--;
    	size-=8;
    	darkzone++;
    	lightzone--;
    	buildHeap();
    }
    /**
     * check if the heap is empty
     * TODO: validate that this logic is correct.
     * @return
     */
    public boolean isEmpty() {
        return (end() < 0) || buff.asLongBuffer().hasRemaining();
    }
    /**
     * get the number of records
     * @return get the number of records
     */
    public int getSize() {
    	return size;
    }
    /**
     * get the number of blocks in this heap
     * @return
     */
    public int getSizeBlocks() {
    	return size/512;
    }
    /**
     * get the right child of pos i
     * @param i current position
     * @return the right child int
     */
    private int right(int i) {
        return 2 * i + 2;
    }
    /**
     * end of the region used to heapify. the value after the 
     * end() will be the maximum value in the darkzone
     * @return size - 1
     */
    private int end() {
        return size - 1;
    }
    /**
     * return the parent to a position in the heap
     * @param i the current position
     * @return the parent. If out of bounds, this will return -1
     */
    protected int parent(int i) {
        if(i < 1 || i >= records) {
            return -1;
        }
        return (i % 2 == 0) ? (i - 1) / 2 : i / 2;
    }
    
    
    /**
     * get the left child of pos i
     * @param i current position
     * @return the left child int
     */
    private int left(int i) {
        return 2 * i + 1;
    }
    /**
     * swap the current position with its parent
     * @param i current pos
     * @param parent the parent of i
     * @return if swap was successful
     */
	protected Boolean swap(int i, int parent) {
	    if(parent < i && parent >= 0 && i < records) {
            long temp = buff.asLongBuffer().get(parent);
            System.out.println(buff.asLongBuffer().get(parent));
            System.out.println(buff.asLongBuffer().get(i));
            buff.asLongBuffer().put(parent, buff.asLongBuffer().get(i));
            buff.asLongBuffer().put(i, temp);
            return true;
	    }
	    return false;
    }
	
	
	/////////////////////////////////////
    /////////////////////////////////////
    /////////////////////////////////////
    /////////////////////////////////////
	/**
	 * 
	 * @param positions a list of the record position to read from
	 * @return the minimum value at the front of each block in main memory
	 * that is identifies by the last position popped from the front
	 */
	protected long mainMemSmallestValue() {
	    int smallestBlock = -1;
	    long smallestValue, tempValue;
	    smallestValue = (long)((0xFFFFFFFF << 32) | 0xFFFFFFFF);
	    for (int i = 1; i < 8; i++) {
	        if (positions.get(i) < 512) { //block has space
	            tempValue = buff.asLongBuffer().get(positions.get(i) + i*512);
	            if(compareTo(tempValue, smallestValue) <= 0) { 
	                smallestValue = tempValue;
	                smallestBlock = i;
	            }
	        }
	    }
	    //pop the smallest value by moving to the next position in its block
	    positions.set(smallestBlock, positions.get(smallestBlock) + 1);
	    return smallestValue;
	}
	
    /**
     * returns the first block number that is all used in the main memory heap
     * @return
     */
    public int getEmptyBlock() {
        for (int i = 0; i < 8; i++) {
            if (positions.get(i) > 4095) {
                return i;
            }
        }
        return -1;
    }
	    
	protected int getNextBlock(int i) {
	    //TODO: if there are no more blocks, return 0xF000. 
	    if(true) {
	        return 0xF000;
	    }
	    return 0;
	}
	protected void updatePositions(ArrayList<Integer> pos) {
	    positions = pos;
	}
}
