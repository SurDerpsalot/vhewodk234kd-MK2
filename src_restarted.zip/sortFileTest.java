/**
 * @author maden
 * unit test for the replacement method
 */
public class sortFileTest extends student.TestCase {

    /**
     * Test method for {@link sortFile#sortFile(
     *  java.lang.String, java.lang.String)}.
     */
    public void testsortFile() {
        try {
            sortFile r = new sortFile("a0.bin", "a1.txt", "a1.bin", "a2.txt");
        }
        catch(Exception e) {
            fail("could not build");
        }
    }

    /**
     * Test method for {@link sortFile#run()}.
     */
    public void testRun() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#fillTheHeap()}.
     */
    public void testFillTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#outTheHeap()}.
     */
    public void testOutTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#resetTheHeap()}.
     */
    public void testResetTheHeap() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link sortFile#compareTo(long, long)}.
     */
    public void testCompareTo() {
        fail("Not yet implemented");
    }

}
